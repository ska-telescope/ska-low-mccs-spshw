"""This subpackage contains code specific to TPM version 1.6."""
