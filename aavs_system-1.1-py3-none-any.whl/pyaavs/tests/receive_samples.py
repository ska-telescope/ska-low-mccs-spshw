import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt

from pydaq import daq_receiver as receiver
from datetime import datetime, timedelta
from pydaq.persisters import *
from pyaavs import station
from config_manager import ConfigManager
from numpy import random
from spead_beam_power_realtime import SpeadRxBeamPowerRealtime
from spead_beam_power_offline import SpeadRxBeamPowerOffline
import spead_beam_power_realtime
import spead_beam_power_offline
import test_functions as tf
import numpy as np
import tempfile
import logging
import shutil
import time
import os
from test_ddr import TestDdr
from test_antenna_buffer import TestAntennaBuffer

buffers_processed = 0
data_ready = False
nof_samples = 256*1024
nof_channels = 8

def station_callback(data_type, filename, samples):
    """ Data callback to process data
    :param data_type: Type of data that was generated
    :param filename: Filename of data file where data was saved """

    global buffers_processed
    global data_ready
    global nof_samples

    if data_ready:
        return

    buffers_processed += 1
    if nof_samples == samples:
        data_ready = True

def initialise_daq(daq_config):
    logging.info("Starting DAQ")
    receiver.populate_configuration(daq_config)
    receiver.initialise_daq()
    receiver.start_continuous_channel_data_consumer(channel_callback)
    # Wait for DAQ to initialise
    tf.accurate_sleep(4)
    logging.info("DAQ initialised")


def stop_daq():
    # Stop DAQ
    try:
        receiver.stop_daq()
    except Exception as e:
        logging.error("Failed to stop DAQ cleanly: {}".format(e))

def initialise_daq()
    global nof_samples
    global nof_channels

    daq_eth_if = 'enp9s0'
    # Generate DAQ configuration
    daq_config = {"nof_channels": 1,
                  "nof_tiles": 1,
                  "nof_channel_samples": nof_samples,
                  "nof_beam_channels": nof_channels,
                  "nof_station_samples": nof_samples,
                  "receiver_interface": daq_eth_if,
                  "receiver_frame_size": 9000}
    # Create temporary directory to store DAQ generated files
    data_directory = tempfile.mkdtemp()
    daq_config['directory'] = data_directory
    logger.info("Using temporary directory {}".format(data_directory))



