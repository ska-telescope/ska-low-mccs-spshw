{{ define "ska-tango-util.dsconfig-properties.tpl" -}}
{{- template "ska-tango-util.1.0.6.dsconfig-properties.tpl" $ }}
{{- end}}
{{ define "ska-tango-util.1.0.6.dsconfig-properties.tpl" -}}
{{- $out := dict }}

{{- if hasKey $.props_obj "properties" }}
  {{- $properties := dict }}
  {{- range $property := $.props_obj.properties }}
    {{- $values := list }}
    {{- range $value := $property.values }}
      {{- $values = append $values (tpl $value $.chart) }}
    {{- end }}
    {{- $_ := set $properties $property.name $values }}
  {{- end }}
  {{- $_ := set $out "properties" $properties}}
{{- end }}

{{- if hasKey $.props_obj "attribute_properties" }}
  {{- $attribute_properties := dict }}
  {{- range $attr_prop := $.props_obj.attribute_properties }}
    {{- $properties := dict }}
    {{- range $property := $attr_prop.properties }}
      {{- $values := list }}
      {{- range $value := $property.values }}
        {{- $values = append $values (tpl $value $.chart) }}
      {{- end }}
      {{- $_ := set $properties $property.name $values }}
    {{- end }}
    {{- $_ := set $attribute_properties $attr_prop.attribute $properties }}
  {{- end }}
  {{- $_ := set $out "attribute_properties" $attribute_properties }}
{{- end }}

{{- $out | toPrettyJson }}

{{- end }}

{{- define "ska-tango-util.dsconfig.tpl" }}
{{- template "ska-tango-util.1.0.6.dsconfig.tpl" $ }}
{{- end}}
{{- define "ska-tango-util.1.0.6.dsconfig.tpl" }}
{{- with .deviceserver.instances }}
servers: 
  '{{ $.deviceserver.server.name }}': 
    {{- range $index_instance,$instance := $.deviceserver.server.instances }}
    {{- if has $instance.name $.deviceserver.instances }}
    '{{ $instance.name }}': 
      {{- range $index_class, $class := $instance.classes }}
      '{{ $class.name }}': 
        {{- range $index_device, $device := $class.devices }}
        {{- $ctx := (dict "chart" .chart "props_obj" $device) }}
        '{{ $device.name }}': 
{{- include "ska-tango-util.1.0.6.dsconfig-properties.tpl" $ctx | fromJson | toYaml | nindent 10}}
        {{- end }}
      {{- end }}
    {{- end }}
    {{- end }}
{{- end }}
{{- with .deviceserver.class_properties }}
classes:
  {{- range $index_class_prop_group, $class_prop_group := . }}
  {{- $ctx := (dict "chart" .chart "props_obj" $class_prop_group) }}
  {{ $class_prop_group.name }}: 
{{- include "ska-tango-util.1.0.6.dsconfig-properties.tpl" $ctx | fromJson | toYaml | nindent 10}}
  {{- end }}
{{- end }}
{{- end }}