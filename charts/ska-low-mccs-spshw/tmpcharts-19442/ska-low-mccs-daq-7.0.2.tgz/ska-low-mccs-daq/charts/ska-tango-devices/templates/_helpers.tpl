{{ define "ska-tango-devices.parse-properties" }}
{{- range $object, $properties := .}}
- name: {{$object}}
{{- $dev_props := dict}}
{{- $att_props := dict}}
{{- range $name, $value := $properties}}
    {{- $value = (kindIs "slice" $value) | ternary $value (list $value) }}
    {{- if contains "->" $name}}
        {{- $att_parts := regexSplit "->" $name 2}}
        {{- $_ := mergeOverwrite $att_props (dict (first $att_parts) (dict (last $att_parts) $value)) }}
    {{- else}}
        {{- $_ := set $dev_props $name $value}}
    {{- end}}
{{- end}}
  properties: {{- empty $dev_props | ternary " []" ""}}
{{- range $name, $value := $dev_props}}
  - name: {{$name}}
    values: {{$value | toStrings | toJson}}
{{- end}}
  attribute_properties: {{- empty $att_props | ternary " []" ""}}
{{- range $attr, $props := $att_props}}
  - attribute: {{$attr}}
    properties:
  {{- range $name, $value := $props}}
    - name: {{$name}}
      values: {{$value | toStrings | toJson}}
  {{- end}}
{{- end}}
{{- end}}
{{- end}}
