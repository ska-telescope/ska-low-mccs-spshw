from __future__ import division

import logging
from builtins import str

from pyfabil.base.definitions import *
from pyfabil.base.utils import *
from pyfabil.boards.tpm import TPM
from pyfabil.protocols.ucp import UCP


class TPM_1_6(TPM):
    """ Support for TPM v 1.6 """

    def __init__(self, **kwargs):
        """ Class constructor """
        kwargs['fpgaBoard'] = BoardMake.Tpm16Board
        kwargs['protocol'] = UCP

        # Set hardcoded CPLD xml offset address
        self._cpld_xml_offset = 0x80000004
        self._cpld_magic = 0xF1233215

        # Initialise variables
        self._simulator = False
        self._initialise = False
        self._enable_ada = False
        self._enable_adc = True

        # CPLD SelectMap Registers
        self._xil_registers = ['board.smap.xil_0', 'board.smap.xil_1']
        self._global_register = 'board.smap.global'
        self._c2c_stream_enable = 'board.regfile.ena_stream'
        self.download_firmware_required_cpld_version = 0

        # Call superclass initialiser
        super(TPM, self).__init__(**kwargs)

        self.BIOS_REV_list = [
            ["0.0.1", "CPLD_0x19121901-MCU_0xb0000010_0x0_0x0"],
            ["0.0.2", "CPLD_0x19122316-MCU_0xb0000010_0x0_0x0"],
            ["0.0.3", "CPLD_0x20011611-MCU_0xb0000010_0x0_0x0"],
            ["0.0.4", "CPLD_0x20011611-MCU_0xb0000016_0x20200123_0x113426"],
            ["0.0.5", "CPLD_0x20041613-MCU_0xb0000016_0x20200123_0x113426"],
            ["0.1.0", "CPLD_0x20111309-MCU_0xb0000100_0x20201120_0xe3f6fa2"],
            ["0.2.0", "CPLD_0x21033009-MCU_0xb0000107_0x20210114_0x0"],
            ["0.2.1", "CPLD_0x21061417-MCU_0xb0000117_0x20210615_0x0"],
        ]

        self.BOARD_MODE = {
            "ada":    0,
            "no-ada": 0xff
        }

    def connect(self, ip, port, fsample=800e6, ddc=False, fddc=0.0, adc_clock_divider=1, **kwargs):
        """ Overload connect method
        :param fsample: Sampling rate
        :param ip: IP address to connect to
        :param port: Port to connect to
        """

        # Check if we are simulating or not
        self._simulator = kwargs.get('simulator', False)

        # Check if we are initialising or not
        self._initialise = kwargs.get('initialise', False)

        # TPM might or might not have an ADA
        self._enable_ada = kwargs.get("enable_ada", False)

        # You can skip ADC enabling for test/debug purpose (default True to preserve back compatibility)
        self._enable_adc = kwargs.get("enable_adc", True)

        # Call connect on super class
        super(TPM, self).connect(ip, port, **kwargs)

        # CPLD is assumed programmed
        self._programmed[Device.Board] = True

        # Try to read address 0x30000000 (CPLD version) check whether TPM is reachable
        try:
            self.read_address(0x30000000)
        except:
            self.status[Device.Board] = Status.NetworkError
            self._connected = False
            raise LibraryError("Could not reach TPM with address {}".format(ip))

        _tmp=self.read_address(0x80000000)
        if _tmp!=self._cpld_magic:
            raise LibraryError("TPM CPLD_MAGIC mismatch. Expected 0x%x, got 0x%x."%(self._cpld_magic,_tmp))

        # Get XML file
        cpld_xml = str(self._get_xml_file(self.read_address(self._cpld_xml_offset)))
        cpld_xml = cpld_xml.replace('<?xml version="1.0" ?>', '')
        cpld_xml = "<node>\n{}\n</node>".format(cpld_xml)

        super(TPM, self).load_firmware(device=Device.Board, register_string=cpld_xml)
        logging.info("tpm.connect: CPLD XML File Downloaded")

        # Load plugins
        self.load_plugins()

        # Initialise devices if required
        if not self._simulator and self._connected:
            if self._initialise:
                self._initialise_devices(fsample=fsample, ddc=ddc, fddc=fddc, adc_clock_divider=adc_clock_divider)
            #else:
            #    self.tpm_pll.pll_reset()

    def load_plugins(self):
        """ Overloaded load_plugins function to load plugins
            for TPM 1.6 """

        # Load the CPLD plugin (does not require the board to be initialised)
        self.load_plugin("Tpm_1_6_ProgFlash")
        self.load_plugin("Tpm_1_6_Cpld")
        self.load_plugin("Tpm_1_6_EEP")

        # Load LASC chip plugin (does not require the board to be initialised)
        self.load_plugin("Tpm_1_6_Mcu")

        if not self._simulator and self._connected:

            # Load QSFP_ADAPTER plugins
            self.load_plugin("Tpm_1_6_QSFPAdapter", core_id=0)
            self.load_plugin("Tpm_1_6_QSFPAdapter", core_id=1)

            # Load PREADU plugins
            self.load_plugin("Tpm_1_6_PreAdu", preadu_id=0)
            self.load_plugin("Tpm_1_6_PreAdu", preadu_id=1)

            # Try initialising the board (will check if FPGAs are programmed)
            if not self._initialise_board():
                return

            # Pre-load all required plugins. Board-level devices are loaded here
            [self.load_plugin("TpmFirmwareInformation", firmware=x) for x in range(1, 4)]

            # Load ADAs
            if self.tpm_eep.get_field("BOARD_MODE") == self.BOARD_MODE['ada']:
                self.load_plugin("TpmAda")

            # Load ADCs
            [self.load_plugin("TpmAdc9695", adc_id=adc) for adc in
                ["adc0", "adc1", "adc2", "adc3", "adc4", "adc5", "adc6", "adc7",
                 "adc8", "adc9", "adc10", "adc11", "adc12", "adc13", "adc14", "adc15"]]

            # Load PLL
            self.load_plugin("Tpm_1_6_Pll")

            # Update firmware information
            if self.is_programmed():
                [info.update_information() for info in self.tpm_firmware_information]

    def download_firmware(self, device, bitfile):
        """ Download bitfile to FPGA
        :param device: FPGA to download bitfile
        :param bitfile: Bitfile to download
        """
        if self["board.regfile.enable.fpga"] == 0:
            logging.info("FPGAs power disabled. Enabling")
            self["board.regfile.enable.fpga"] = 1
            time.sleep(0.1)
        else:
            logging.info("FPGAs power already enabled.")

        # Lock SMAP interface to avoi MCU access conflict
        logging.info("Locking SMAP interface to avoid MCU access conflict")
        locked = False
        retry = 10
        while retry > 0:
            self["board.lock.mlock1"] = 0x50000000
            if self["board.lock.mlock1"] != 0x50000000:
                retry = retry-1
                time.sleep(0.01)
            else:
                locked = True
                break
        if locked is False:
            logging.error("ERROR: Can't Lock SMAP interface")
            raise LibraryError("ERROR: Can't Lock SMAP interface")
        # Program FPGA
        super(TPM_1_6, self).download_firmware(device, bitfile)
        # Unlock SMPA interface
        self["board.lock.mlock1"] = 0xFFFFFFFF

    def is_programmed(self, fpga_id=None):
        """ Returns True if Board is programmed """

        if not self.is_connected():
            logging.debug("tpm.is_programmed")
            return None

        logging.debug("FPGAs is_programmed? Enable %d, Done[0-1] %d" % (
        self['board.regfile.enable.fpga'], self['board.regfile.xilinx.done']))
        self._programmed[Device.FPGA_1] = self['board.regfile.enable.fpga'] and bool(
            self['board.regfile.xilinx.done'] & 0x1)
        self._programmed[Device.FPGA_2] = self['board.regfile.enable.fpga'] and bool(
            self['board.regfile.xilinx.done'] & 0x2)

        if fpga_id is None:
            if (not self._programmed[Device.FPGA_1]) and (not self._programmed[Device.FPGA_2]):
                logging.debug("Return False")
                return False
            logging.debug("Return True")
            return True
        else:
            if fpga_id == 0:
                logging.debug("Return %s" % self._programmed[Device.FPGA_1])
                return bool(self._programmed[Device.FPGA_1])
            elif fpga_id == 1:
                logging.debug("Return %s" % self._programmed[Device.FPGA_2])
                return bool(self._programmed[Device.FPGA_2])
        return None

    def set_lmc_ip(self, ip="10.0.10.1", port=None, port2=None, port3=None, same_port=True):
        """ Set the IP address for LMC data transfer
        :param ip: IP address in string form
        :param port: Port
        :param port2: Port for stream 1
        :param port3: Port for stream 2
        :param same_port: Use the same port for all ports
        """
        # Set Stream 0:
        # Set LMC IP
        self['board.regfile.stream_dst_ip0'] = struct.unpack("!I", socket.inet_aton(ip))[0]

        # Set LMC destination and source port
        if port is None or type(port) is not int:
            port = self['board.regfile.stream_dst_port0'] & 0xFFFF

        self['board.regfile.stream_src_port0'] = 10001
        self['board.regfile.stream_dst_port0'] = port

        # Set Stream 1:
        # Set LMC IP
        self['board.regfile.stream_dst_ip1'] = struct.unpack("!I", socket.inet_aton(ip))[0]

        # Set LMC destination and source port
        self['board.regfile.stream_src_port1'] = 10001
        if port2 is not None and type(port) is int:
            self['board.regfile.stream_dst_port1'] = port2
        elif same_port:
            self['board.regfile.stream_dst_port1'] = port

        # # Set Stream 2:
        # # Set LMC IP
        # self['board.regfile.stream_dst_ip2']  = struct.unpack("!I", socket.inet_aton(ip))[0]
        #
        # # Set LMC destination and source port
        # self['board.regfile.stream_src_port2'] = 10001
        # if port3 is not None and type(port) is int:
        #     self['board.regfile.stream_dst_port2'] = port3
        # elif same_port:
        #     self['board.regfile.stream_dst_port2'] = port

    def temperature(self):
        """ Get board temperature """
        return self.tpm_monitor.get_temperature()

    def voltage(self):
        """ Get board voltage """
        return self.tpm_monitor.get_voltage_5v0()

    def get_part_number(self):
        return self.tpm_eep.get_field("PN")

    def get_serial_number(self):
        return self.tpm_eep.get_field("SN")

    def get_hardware_revision(self):
        hw_rev_arr = self.tpm_eep.get_field("HARDWARE_REV")
        hw_rev = 0
        for byte in hw_rev_arr:
            hw_rev = hw_rev * 256 + byte
        if hw_rev == 0xffffff or hw_rev == 0x0:
            hw_rev = self.tpm_hw_rev_1_2
        return hw_rev

    def get_bios(self):
        string = "CPLD_"
        string += self.tpm_cpld.get_version()
        string += "-MCU_"
        string += self.tpm_monitor.get_version()
        final_string = "v?.?.? (%s)" % string
        for BIOS_REV in self.BIOS_REV_list:
            if BIOS_REV[1] == string:
                final_string = "v%s (%s)" % (BIOS_REV[0], string)
                break
        return final_string

    def get_mac(self):
        mac = self.tpm_eep.get_field("MAC")
        mac_str = ""
        for i in range(0,len(mac)-1):
            mac_str += '{0:02x}'.format(mac[i])+":"
        mac_str += '{0:02x}'.format(mac[len(mac)-1])
        return mac_str

    def get_board_info(self):
        tpm_info = {"ip_address": long2ip(self['board.regfile.eth_ip']),
                    "netmask": long2ip(self['board.regfile.eth_mask']),
                    "gateway": long2ip(self['board.regfile.eth_gway']),
                    "ip_address_eep": self.tpm_eep.get_field("ip_address"),
                    "netmask_eep": self.tpm_eep.get_field("netmask"),
                    "gateway_eep": self.tpm_eep.get_field("gateway"),
                    "MAC": self.get_mac(),
                    "SN": self.get_serial_number(),
                    "PN": self.get_part_number(),
                    "bios": self.get_bios(),
                    }

        if self.tpm_eep.get_field("BOARD_MODE") == self.BOARD_MODE['ada']:
            tpm_info["BOARD_MODE"] = "ADA"

        elif self.tpm_eep.get_field("BOARD_MODE") == self.BOARD_MODE['no-ada']:
            tpm_info["BOARD_MODE"] = "NO-ADA"
        else:
            tpm_info["BOARD_MODE"] = "UNKNOWN"

        location = [self.tpm_eep.get_field("CABINET_LOCATION"),
                    self.tpm_eep.get_field("SUBRACK_LOCATION"),
                    self.tpm_eep.get_field("SLOT_LOCATION")]
        tpm_info["LOCATION"] = str(location[0]) + ":" + str(location[1]) + ":" + str(location[2])

        pcb_rev = self.tpm_eep.get_field("PCB_REV")
        if pcb_rev == 0xff:
            pcb_rev_string = ""
        else:
            pcb_rev_string = str(pcb_rev)

        hw_rev = self.tpm_eep.get_field("HARDWARE_REV")
        tpm_info["HARDWARE_REV"] = "v" + str(hw_rev[0]) + "." + str(hw_rev[1]) + "." + str(hw_rev[2]) + pcb_rev_string

        ddr_size = self.tpm_eep.get_field("DDR_SIZE_GB")
        if ddr_size == 0xff:
            tpm_info["DDR_SIZE_GB"] = "4"
        else:
            tpm_info["DDR_SIZE_GB"] = str(ddr_size)
        return tpm_info

    def get_global_status_alarms(self):
        alarms = {"temperature_alm": self['board.regfile.global_status.temperature'],
                  "voltage_alm": self['board.regfile.global_status.voltage'],
                  "SEM_wd": self['board.regfile.global_status.SEM'],
                  "MCU_wd": self['board.regfile.global_status.MCU']}
        return alarms



    def _initialise_devices(self, fsample=800e6, ddc=False, fddc=0.0, adc_clock_divider=1):
        """ Initialise the SPI and other devices on the board """

        # self.set_shutdown_temperature(65)

        # Switch voltages ON
        # self['board.regfile.ctrl.en_ddr_vdd'] = 1

        # Initialise PLL (3 retries)
        for i in range(3):
            try:
                self.tpm_pll.pll_start(fsample)
                break
            except PluginError as err:
                if i == 2:
                    raise err

        # Initialise ADAs if required
        # self.tpm_ada.disable_adas()
        if self._enable_ada:
            logging.info("Enabling ADAs")
            self.tpm_ada.initialise_adas()
        else:
            logging.info("Not enabling ADAs")

        # Initialise ADCs
        if self._enable_adc:
            [self.tpm_adc[i].adc_single_start() for i in range(len(self.tpm_adc))]


if __name__ == "__main__":

    # Enable debug logging
    from sys import stdout
    log = logging.getLogger('')
    log.setLevel(logging.DEBUG)
    line_format = logging.Formatter("%(asctime)s - %(levelname)s - %(threadName)s - %(message)s")
    ch = logging.StreamHandler(stdout)
    ch.setFormatter(line_format)
    log.addHandler(ch)

    # Test TPM
    tpm = TPM_1_6(ip="10.0.10.2")
    tpm.connect(ip="10.0.10.2", port=10000)
    print(tpm.get_board_info())
