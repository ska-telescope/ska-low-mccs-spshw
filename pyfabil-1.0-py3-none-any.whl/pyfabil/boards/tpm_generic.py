from __future__ import division
from builtins import str
from builtins import hex
from builtins import range
import binascii
import logging
import math
import socket
import struct
import time
import zlib
from math import ceil
from time import sleep

from pyfabil.base.definitions import *
from pyfabil.boards.fpgaboard import FPGABoard, DeviceNames
from pyfabil.protocols.ucp import UCP


class TPMGeneric(FPGABoard):
    """ FPGABoard subclass for communicating with a TPM board """

    def __init__(self, **kwargs):
        """ Class constructor """
        kwargs['fpgaBoard'] = BoardMake.TpmBoard
        kwargs['protocol'] = UCP

        # Set hardcoded CPLD xml offset address
        self._cpld_magic_offset = 0x80000000
        # self._cpld_xml_offset = 0x80000004
        self._cpld_magic_tpm_v1_2 = 0xF1233210
        self._cpld_magic_tpm_v1_5 = 0xF1233215

        # Call superclass initialiser
        super(TPMGeneric, self).__init__(**kwargs)

    def get_tpm_version(self, ip, port, **kwargs):
        """ Overload connect method
        :param fsample: Sampling rate
        :param ip: IP address to connect to
        :param port: Port to connect to
        """

        super(TPMGeneric, self).connect(ip, port, **kwargs)
        # _tpm_version = self.read_address(self._cpld_magic_offset)
        # Try to read address 0x30000000 (CPLD version) check whether TPM is reachable
        try:
            _tpm_version = self.read_address(self._cpld_magic_offset)
        except:
            raise LibraryError("Could not reach TPM with address {}".format(ip))

        if _tpm_version == self._cpld_magic_tpm_v1_2:
            return "tpm_v1_2"

        elif _tpm_version == self._cpld_magic_tpm_v1_5:
            return "tpm_v1_5"
        else:
            raise LibraryError("TPM CPLD_MAGIC mismatch. Got 0x%x." %_tpm_version)



# ------------------------------------------------ Tile Class ---------------------------------------

if __name__ == "__main__":
    tpm = TPM()
    tpm.connect(ip="10.0.10.13", port=10000)
