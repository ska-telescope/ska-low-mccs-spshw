from __future__ import division
from builtins import str
from builtins import hex
from builtins import range
import socket
import time

__author__ = 'lessju'

from pyfabil.plugins.firmwareblock import FirmwareBlock
from pyfabil.base.definitions import *
from pyfabil.base.utils import *
import logging


class TpmFortyGCoreXg(FirmwareBlock):
    """ TpmFortyGCoreXg plugin  """

    @compatibleboards(BoardMake.TpmBoard)
    @friendlyname('tpm_10g_core')
    @maxinstances(2)
    def __init__(self, board, **kwargs):
        """ TpmFortyGCoreXg initialiser
        :param board: Pointer to board instance
        """
        super(TpmFortyGCoreXg, self).__init__(board)

        if 'device' not in list(kwargs.keys()):
            raise PluginError("TpmFortyGCoreXg: Require a node instance")
        self._device = kwargs['device']

        if 'core' not in list(kwargs.keys()):
            raise PluginError("TpmFortyGCoreXg: core_id required")

        if self._device == Device.FPGA_1:
            self._device = 'fpga1'
        elif self._device == Device.FPGA_2:
            self._device = 'fpga2'
        else:
            raise PluginError("TpmFortyGCoreXg: Invalid device %s" % self._device)

        self._core = kwargs['core']
        self._src_port = [0]*32
        self._tx_config_ip_ba = self.board.memory_map['%s.xg_udp.core%d_tx_config_ip' % (self._device, self._core)].address
        self._tx_config_port_ba = self.board.memory_map['%s.xg_udp.core%d_tx_config_port' % (self._device, self._core)].address
    #######################################################################################

    def initialise_core(self):
        """ Initialise 40G core """
        if int(self._core) == 0:
            self.board['%s.xg_udp.phy_ctrl.rst' % self._device] = 0
            self.board['%s.xg_udp.phy_ctrl.rst' % self._device] = 1
            self.board['%s.xg_udp.phy_ctrl.rst' % self._device] = 0
        self.board['%s.xg_udp.core%d_global_config.tx_use_always_0' % (self._device, self._core)] = 0
        self.board['%s.xg_udp.core%d_global_config.promiscuous_mode_enable' % (self._device, self._core)] = 0
        return

    def set_src_mac(self, mac):
        """ Set source MAC address
        :param mac: MAC address
        """
        self.board['%s.xg_udp.core%d_mac_lsb' % (self._device, self._core)] = mac & 0xFFFFFFFF
        self.board['%s.xg_udp.core%d_mac_msb' % (self._device, self._core)] = (mac >> 32) & 0xFFFFFFFF

    def get_src_mac(self):
        """ Get source MAC address """
        lower = self.board['%s.xg_udp.core%d_mac_lsb' % (self._device, self._core)]
        upper = self.board['%s.xg_udp.core%d_mac_msb' % (self._device, self._core)]
        return upper << 32 | lower

    def set_dst_mac(self, mac):
        """ Set destination MAC address
        :param mac: MAC address
        """
        return

    def get_dst_mac(self):
        """ Get destination MAC address """
        return 0

    def set_src_ip(self, ip):
        """ Set source IP address
        :param ip: IP address
        """
        try:
            if type(ip) is not int:
                ip = struct.unpack("!L", socket.inet_aton(ip))[0]
            self.board['%s.xg_udp.core%d_ip' % (self._device, self._core)] = ip
            self.board['%s.xg_udp.core%d_netmask' % (self._device, self._core)] = 0xFF000000
        except:
            raise PluginError("TpmFortyGCoreXg: Could not set source IP")

    def get_src_ip(self):
        """ Get source IP address """
        return self.board['%s.xg_udp.core%d_ip' % (self._device, self._core)]

    def set_dst_ip(self, ip, arp_table_entry=0):
        """ Set source IP address
        :param ip: IP address
        :param arp_table_entry: entry in the core ARP table
        """
        try:
            if type(ip) is not int:
                ip = struct.unpack("!L", socket.inet_aton(ip))[0]
            self.board[self._tx_config_ip_ba + 4 * arp_table_entry] = ip
        except:
            raise PluginError("TpmFortyGCoreXg: Could not set destination IP %s" % ip)

    def get_dst_ip(self, arp_table_entry=0):
        """ Get destination ip
        :param arp_table_entry: entry in the core ARP table
        """
        return self.board[self._tx_config_ip_ba + 4 * arp_table_entry]

    def set_src_port(self, port, arp_table_entry=0):
        """ Set source IP address
        :param port: Port
        :param arp_table_entry: entry in the core ARP table
        """
        self._src_port[arp_table_entry] = port
        return

    def get_src_port(self, arp_table_entry=0):
        """ Get source IP address
        :param port: Port
        :param arp_table_entry: entry in the core ARP table
        """
        return self._src_port[arp_table_entry]

    def set_dst_port(self, port, arp_table_entry=0):
        """ Set source IP address
        :param port: Port
        :param arp_table_entry: entry in the core ARP table
        """
        self.board[self._tx_config_port_ba + 4 * arp_table_entry] = port | (self._src_port[arp_table_entry] << 16)

    def get_dst_port(self,arp_table_entry=0):
        """ Set source IP address
        :param port: Port
        :param arp_table_entry: entry in the core ARP table
        """
        return self.board[self._tx_config_port_ba + 4 * arp_table_entry] >> 16

    def get_arp_table_status(self, idx, silent_mode=True):
        self.board['%s.xg_udp.core%d_arp_table_read_pointer' % (self._device, self._core)] = idx
        rd = self.board['%s.xg_udp.core%d_arp_table_status' % (self._device, self._core)]
        mac_lsb = self.board['%s.xg_udp.core%d_arp_table_mac_lsb' % (self._device, self._core)]
        mac_msb = self.board['%s.xg_udp.core%d_arp_table_mac_msb' % (self._device, self._core)]
        if not silent_mode:
            txt = "\n\nvalid: " + str(rd & 0x1) + "\n"
            txt += "renewing: " + str((rd & 0x2) >> 1) + "\n"
            txt += "mac_resolved: " + str((rd & 0x4) >> 2) + "\n"
            txt += "mac: " + hex((mac_msb << 32) + mac_lsb) + "\n"
            logging.info(txt)
        return rd

    def test_stop(self):
        self.board['%s.xg_udp.core%d_test_ctrl_0.tx_start' % (self._device, self._core)] = 0
        self.board['%s.xg_udp.core%d_test_ctrl_0.rx_start' % (self._device, self._core)] = 0

    def test_start_tx(self, dst_ip=None, ipg=4, packet_len=8192):
        self.board['%s.xg_udp.core%d_test_ctrl_0.tx_start' % (self._device, self._core)] = 0
        if dst_ip is not None:
            self.set_dst_ip(dst_ip)
        self.board['%s.xg_udp.core%d_test_ctrl_1.ipg' % (self._device, self._core)] = ipg
        self.board['%s.xg_udp.core%d_test_ctrl_1.pkt_len' % (self._device, self._core)] = packet_len
        self.board['%s.xg_udp.core%d_test_ctrl_0.tx_start' % (self._device, self._core)] = 1

    def test_start_rx(self):
        self.board['%s.xg_udp.core%d_test_ctrl_0.rx_start' % (self._device, self._core)] = 0
        self.board['%s.xg_udp.core%d_test_ctrl_0.rx_start' % (self._device, self._core)] = 1

    def test_check_result(self):
        print("Error detected: %d" % self.board['%s.xg_udp.core%d_test_status.error' % (self._device, self._core)])
        print("Error counter: %d" % self.board['%s.xg_udp.core%d_test_error_cnt' % (self._device, self._core)])
        print("TX packet counter: %d" % self.board['%s.xg_udp.core%d_test_tx_pkt_cnt' % (self._device, self._core)])
        print("RX packet counter: %d" % self.board['%s.xg_udp.core%d_test_rx_pkt_cnt' % (self._device, self._core)])
    ##################### Superclass method implementations #################################

    def initialise(self):
        """ Initialise TpmFortyGCoreXg """
        logging.info("TpmFortyGCoreXg has been initialised")
        return True

    def status_check(self):
        """ Perform status check
        :return: Status
        """
        logging.info("TpmFortyGCoreXg : Checking status")
        return Status.OK

    def clean_up(self):
        """ Perform cleanup
        :return: Success
        """
        logging.info("TpmFortyGCoreXg : Cleaning up")
        return True
