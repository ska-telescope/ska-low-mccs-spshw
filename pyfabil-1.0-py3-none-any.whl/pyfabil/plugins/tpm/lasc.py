from builtins import object
__author__ = 'lessju'

from pyfabil.plugins.firmwareblock import FirmwareBlock
from pyfabil.base.definitions import *
from pyfabil.base.utils import *
import logging
import time

class lasc_reg(object):
    adc_mux = 0x00
    adc_lRADC = 0x01
    adc_hRADC = 0x02
    imon_ctrl = 0x03
    imon_select = 0x04
    imon_avg_l = 0x05
    imon_avg_h = 0x06
    monitor_select = 0x07
    monitor_record = 0x08
    output_ctrl_blk = 0x70
    tmon_1_h = 0x80
    tmon_1_l = 0x81
    tmon_2_h = 0x82
    tmon_2_l = 0x83
    tmon_int_h = 0x84
    tmonint_l = 0x85
    tmon_stat_a1 = 0x86
    tmon_stat_b = 0x87

class lasc_inst(object):
    READ_ID = 0x2
    READ_STATUS = 0x3
    WRITE_MEAS_CTRL = 0x51
    READ_MEAS_CTRL = 0x52


class TpmLasc(FirmwareBlock):
    """ FirmwareBlock tests class """

    @compatibleboards(BoardMake.TpmBoard)
    @friendlyname('tpm_lasc')
    @maxinstances(1)
    def __init__(self, board, **kwargs):
        """ TpmLasc initialiser
        :param board: Pointer to board instance
        """
        super(TpmLasc, self).__init__(board)

        self._board_type = kwargs.get('board_type', 'XTPM')

    #######################################################################################

    def lasc_write(self, is_code, data):
        ba = 0x40000000
        add = 0xC0 >> 1
        nof_rd_byte = 0
        nof_wr_byte = 3
        cmd = (nof_rd_byte << 12) + (nof_wr_byte << 8) + add

        while True:
            self.board[ba + 0x4] = ((is_code & 0xFF) << 8) + (data & 0xFF)
            self.board[ba + 0x0] = cmd
            while True:
                rd = self.board[ba + 0xC]
                if rd == 2:
                    time.sleep(0.02)
                    break
                elif rd == 0:
                    return
                else:
                    time.sleep(0.02)

    def lasc_write_mctrl(self, is_code, regadd, data):
        ba = 0x40000000
        add = 0xC0 >> 1
        nof_rd_byte = 0
        nof_wr_byte = 4
        cmd = (nof_rd_byte << 12) + (nof_wr_byte << 8) + add

        while True:
            self.board[ba + 0x4] = ((data & 0xFF) << 16) + ((regadd & 0xFF) << 8)+ (is_code & 0xFF)
            self.board[ba + 0x0] = cmd
            while True:
                rd = self.board[ba + 0xC]
                if rd == 2:
                    time.sleep(0.02)
                    break
                elif rd == 0:
                    return
                else:
                    time.sleep(0.02)

    def lasc_read(self, is_code, rnbyte):
        ba = 0x40000000
        add = 0xC0 >> 1
        nof_rd_byte = rnbyte
        nof_wr_byte = 1
        cmd = (nof_rd_byte << 12) + (nof_wr_byte << 8) + add
        time.sleep(0.02)
        self.board[ba + 0x4] = is_code & 0xFF
        self.board[ba + 0x0] = cmd

        while self.board[ba + 0xC] != 0:
            pass

        time.sleep(0.02)
        rdata = self.board[ba + 0x8]
        return rdata

    def lasc_read_mctrl(self, is_code, regadd, rnbyte):
        ba = 0x40000000
        add = 0xC0 >> 1
        nof_rd_byte = rnbyte
        nof_wr_byte = 2
        cmd = (nof_rd_byte << 12) + (nof_wr_byte << 8) + add
        time.sleep(0.02)
        self.board[ba + 0x4] = ((regadd  & 0xFF) << 8) + (is_code & 0xff)
        self.board[ba + 0x0] = cmd

        while self.board[ba + 0xC] != 0:
            pass

        time.sleep(0.02)
        rdata = self.board[ba + 0x8]
        return rdata

    def read_id(self):
        id = self.lasc_read(lasc_inst.READ_ID, 1)
        return id

    def read_vmon1(self):
        self.lasc_write_mctrl(lasc_inst.WRITE_MEAS_CTRL, lasc_reg.adc_mux, 0x80)
        time.sleep(0.02)
        vmon1_l = self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_lRADC, 0x1)
        vmon1_h = self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_hRADC, 0x1)
        vmon1_value = (vmon1_h << 5)+((vmon1_l & 0xF8) >> 3)
        return vmon1_value*2

    def read_vmon2to7(self,mon_id):
        if mon_id < 2 or mon_id > 7:
            logging.error("TpmLasc: Invalid id channel")
            return -1

        self.lasc_write_mctrl(lasc_inst.WRITE_MEAS_CTRL, lasc_reg.adc_mux, (0x0+(mon_id-1)))
        time.sleep(0.02)
        vmon2_7_l = self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_lRADC, 0x1)
        vmon2_7_h = self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_hRADC, 0x1)
        vmon2_7_value = (vmon2_7_h << 5)+((vmon2_7_l & 0xF8) >> 3)
        return vmon2_7_value*2

    def read_vmon8(self):
        self.lasc_write_mctrl(lasc_inst.WRITE_MEAS_CTRL, lasc_reg.adc_mux, (0x87))
        time.sleep(0.02)
        vmon8_l=self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_lRADC, 0x1)
        vmon8_h=self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_hRADC, 0x1)
        vmon8_value = (vmon8_h << 5)+((vmon8_l & 0xF8) >> 3)
        return vmon8_value*2

    def read_vmon9(self):
        self.lasc_write_mctrl(lasc_inst.WRITE_MEAS_CTRL, lasc_reg.adc_mux, (0x88))
        time.sleep(0.02)
        vmon9_l=self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_lRADC, 0x1)
        vmon9_h=self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_hRADC, 0x1)
        vmon9_value=(vmon9_h << 5)+((vmon9_l & 0xF8) >> 3)
        return vmon9_value*2

    def read_hvmon(self):
        self.lasc_write_mctrl(lasc_inst.WRITE_MEAS_CTRL, lasc_reg.adc_mux, (0x89))
        time.sleep(0.02)
        hvmon_l = self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_lRADC, 0x1)
        hvmon_h = self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_hRADC, 0x1)
        hvmon_value=(hvmon_h << 5)+((hvmon_l & 0xF8) >> 3)
        return hvmon_value*2

    def read_himon(self):
        self.lasc_write_mctrl(lasc_inst.WRITE_MEAS_CTRL, lasc_reg.adc_mux, (0x13))
        time.sleep(0.02)
        hvmon_l=self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_lRADC, 0x1)
        hvmon_h=self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_hRADC, 0x1)
        hvmon_value=(hvmon_h<<5)+((hvmon_l&0xF8)>>3)
        return hvmon_value*2

    def read_imon(self):
        self.lasc_write_mctrl(lasc_inst.WRITE_MEAS_CTRL, lasc_reg.adc_mux, (0x80))
        time.sleep(0.02)
        hvmon_l=self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_lRADC, 0x1)
        hvmon_h=self.lasc_read_mctrl(lasc_inst.READ_MEAS_CTRL, lasc_reg.adc_hRADC, 0x1)
        hvmon_value=(hvmon_h<<5)+((hvmon_l&0xF8)>>3)
        return hvmon_value*2

    def get_voltage_5v0(self):
        return round(self.read_vmon1() * 0.001, 2)

    def get_voltage_fpga0(self):
        return round(self.read_vmon2to7(2) * 0.001, 2)

    def get_voltage_fpga1(self):
        return round(self.read_vmon2to7(3) * 0.001, 2)

    def get_voltage_av(self):
        return round(self.read_vmon2to7(4) * 0.001, 2)

    def get_voltage_avtt(self):
        return round(self.read_vmon2to7(5) * 0.001, 2)

    def get_voltage_vcc_aux(self):
        return round(self.read_vmon2to7(6) * 0.001, 2)

    def get_voltage_avdd1(self):
        return round(self.read_vmon2to7(7) * 0.001, 2)

    def get_voltage_avdd2(self):
        return round(self.read_vmon8() * 0.001, 2)

    def get_voltage_avdd3(self):
        return round(self.read_vmon9() * 0.001, 2)

    ##################### Superclass method implementations #################################

    def initialise(self):
        """ Initialise TpmLasc """
        logging.info("TpmLasc has been initialised")
        return True


    def status_check(self):
        """ Perform status check
        :return: Status
        """
        logging.info("TpmLasc : Checking status")
        return Status.OK


    def clean_up(self):
        """ Perform cleanup
        :return: Success
        """
        logging.info("TpmLasc : Cleaning up")
        return True
