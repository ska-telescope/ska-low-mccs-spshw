from __future__ import division
from builtins import str
from builtins import range
from past.utils import old_div
__author__ = 'lessju'

from pyfabil.plugins.firmwareblock import FirmwareBlock
from pyfabil.base.definitions import *
from pyfabil.base.utils import *
import logging
import time


class TpmPll(FirmwareBlock):
    """ FirmwareBlock tests class """

    @compatibleboards(BoardMake.TpmBoard)
    @friendlyname('tpm_pll')
    @maxinstances(1)
    def __init__(self, board, **kwargs):
        """ TpmPll initialiser
        :param board: Pointer to board instance
        """
        super(TpmPll, self).__init__(board)

        self._board_type = kwargs.get('board_type', 'XTPM')

        self._pll_out_config = []
        if self._board_type == "XTPM":
            self._pll_out_config = ["sysref",
                                    "clk",
                                    "clk",
                                    "unused",
                                    "sysref",
                                    "unused",
                                    "vcxo",
                                    "unused",
                                    "vcxo",
                                    "sysref_pll1_retimed",
                                    "sysref_pll1_retimed",
                                    "unused",
                                    "vcxo",
                                    "vcxo"]
        else:
            raise PluginError("TpmPll: Board type not supported")

    #######################################################################################
    def pll_out_set(self, idx):
        """ Set PLL out
        :param idx:
        :return:
        """

        type = self._pll_out_config[idx]

        if type == "clk":
            reg0 = 0x0
            reg1 = 0x0
            reg2 = 0x0
        elif type == "clk_div_4":
            reg0 = 0x0
            reg1 = 0x0
            reg2 = 0x3
        elif type == "vcxo":
            reg0 = 0x20
            reg1 = 0x0
            reg2 = 0x0
        elif type == "inverted_vcxo":
            reg0 = 0xA0
            reg1 = 0x0
            reg2 = 0x0
        elif type == "sysref":
            reg0 = 0x40
            reg1 = 0x0
            reg2 = 0x0
        elif type == "sysref_pll1_retimed":
            reg0 = 0x60
            reg1 = 0x0
            reg2 = 0x0
        elif type == "sysref_hstl":
            reg0 = 0x40
            reg1 = 0x80
            reg2 = 0x0
        else:
            reg0 = 0x0
            reg1 = 0x0
            reg2 = 0x0

        return reg0, reg1, reg2

    def pll_config(self, fsample):
        """ Configure the PLL
        :param fsample:
        """
        if self._board_type == "XTPM":
            # PLL1 config
            self.board[('pll', 0x100)] = 0x1
            self.board[('pll', 0x102)] = 0x1
            self.board[('pll', 0x104)] = 0xA  # VCXO100MHz
            self.board[('pll', 0x106)] = 0x14  # VCXO100MHz ##mod
            self.board[('pll', 0x107)] = 0x13  # Not disable holdover
            self.board[('pll', 0x108)] = 0x28  # VCXO100MHz
            self.board[('pll', 0x109)] = 0x0  # setting PLL1 feedback source as PLL2 divider output
            self.board[('pll', 0x10A)] = 0x2  # 10MHZ: 0x2
            # PLL2 config
            self.board[('pll', 0x200)] = 0xE6
            if fsample == 1000e6:
                self.board[('pll', 0x201)] = 0x0A
                self.board[('pll', 0x202)] = 0x13
                self.board[('pll', 0x203)] = 0x00
                self.board[('pll', 0x204)] = 0x4  # M1
                self.board[('pll', 0x205)] = 0x7
                self.board[('pll', 0x207)] = 0x2  # R1
                self.board[('pll', 0x208)] = 0x9  # N2
            elif fsample == 800e6:
                self.board[('pll', 0x201)] = 0x0A
                self.board[('pll', 0x202)] = 0x13
                self.board[('pll', 0x203)] = 0x00
                self.board[('pll', 0x204)] = 0x5  # M1
                self.board[('pll', 0x205)] = 0x7
                self.board[('pll', 0x207)] = 0x2  # R1
                self.board[('pll', 0x208)] = 0x7  # N2
            elif fsample == 700e6:
                self.board[('pll', 0x201)] = 0xC8
                self.board[('pll', 0x202)] = 0x13
                self.board[('pll', 0x203)] = 0x00
                self.board[('pll', 0x204)] = 0x5  # M1
                self.board[('pll', 0x205)] = 0x7
                self.board[('pll', 0x207)] = 0x0  # R1
                self.board[('pll', 0x208)] = 0x6  # N2
            else:
                raise PluginError("TpmPll: Frequency not supported")
        else:
            raise PluginError("TpmPll: Board type not supported")

        # Setting PLL Outputs
        for n in range(14):
            reg0, reg1, reg2 = self.pll_out_set(n)
            self.board[('pll', 0x300 + 3 * n + 0)] = reg0
            self.board[('pll', 0x300 + 3 * n + 1)] = reg1
            self.board[('pll', 0x300 + 3 * n + 2)] = reg2

        # Setting SYSREF
        divider = 640  # sysref: divide by 640(*2)
        self.board[('pll', 0x400)] = divider & 0xFF
        self.board[('pll', 0x401)] = (divider >> 8) & 0xFF
        self.board[('pll', 0x402)] = 0x0
        self.board[('pll', 0x403)] = 0x96

        # Power down unused output
        self.board[('pll', 0x500)] = 0x10
        pd = 0
        for c in range(14):
            if self._pll_out_config[c] == "unused":
                pd |= 2 ** c
        self.board[('pll', 0x501)] = pd & 0xFF
        self.board[('pll', 0x502)] = (pd & 0xFF00) >> 8
        self.board[('pll', 0x503)] = ~pd & 0xFF
        self.board[('pll', 0x504)] = (~pd & 0xFF00) >> 8

        # IO update command
        self.board[('pll', 0xF)] = 0x1
        for i in range(10):
            if self.board[('pll', 0xF)] == 0:
                break
            if i == 9:
                raise PluginError("TpmPll: ")
            time.sleep(0.1)

        # Enable sysref
        self.board[('pll', 0x403)] = 0x97
        if do_until_eq(lambda: self.board[('pll', 0xF)], 0, ms_retry=100, s_timeout=10) is None:
            raise PluginError("PLL timeout error")
        self.board[('pll', 0xF)] = 0x1

        # SYNC command
        self.board[('pll', 0x32A)] = 0x1
        if do_until_eq(lambda: self.board[('pll', 0xF)], 0, ms_retry=100, s_timeout=10) is None:
            raise PluginError("PLL timeout error")
        self.board[('pll', 0xF)] = 0x1

        # SYNC command
        self.board[('pll', 0x32A)] = 0x0
        if do_until_eq(lambda: self.board[('pll', 0xF)], 0, ms_retry=100, s_timeout=10) is None:
            raise PluginError("PLL timeout error")
        self.board[('pll', 0xF)] = 0x1

        # PLL2 VCO calibration
        self.board[('pll', 0x203)] = 0x00
        self.board[('pll', 0xF)] = 0x1
        if do_until_eq(lambda: self.board[('pll', 0xF)], 0, ms_retry=100, s_timeout=10) is None:
            raise PluginError("PLL timeout error")

        self.board[('pll', 0x203)] = 0x01
        self.board[('pll', 0xF)] = 0x1
        if do_until_eq(lambda: self.board[('pll', 0xF)], 0, ms_retry=100, s_timeout=10) is None:
            raise PluginError("PLL timeout error")

        if do_until_eq(lambda: self.board[('pll', 0x509)] & 0x1, 0x0, ms_retry=100, s_timeout=10) is None:
            raise PluginError("PLL VCO calibration timeout")

        if do_until_eq(lambda: self.board[('pll', 0x508)] in [0xF2, 0xE7], 0x1, ms_retry=100, s_timeout=10) is None:
            raise PluginError("PLL not locked")

    def pll_start(self, fsample):
        """ Perform the PLL initialization procedure as implemented in ADI demo
        :param fsample: PLL output frequency in MHz. Supported frequency are 700, 800, 1000 MHz
        """

        if fsample not in [1000e6, 800e6, 700e6]:
            logging.warn("TpmPLL: Frequency " + str(fsample / 1e6) + " MHz is not currently supported.")
            fsample = 800e6

        self.board['board.regfile.ctrl.ad9528_rst'] = 1
        self.board['board.regfile.ctrl.ad9528_rst'] = 0
        time.sleep(0.2)
        self.board['board.regfile.ctrl.ad9528_rst'] = 1
        time.sleep(0.2)

        self.board['fpga1.pps_manager.pps_in_invert'] = 0x1
        self.board['fpga1.pps_manager.sync_tc'] = 0x07090404
        self.board['fpga1.pps_manager.sync_prescale'] = 0x0
        self.board['fpga1.pps_manager.sync_cnt_enable'] = 0x7

        self.board['fpga2.pps_manager.pps_in_invert'] = 0x1
        self.board['fpga2.pps_manager.sync_tc'] = 0x07090404
        self.board['fpga2.pps_manager.sync_prescale'] = 0x0
        self.board['fpga2.pps_manager.sync_cnt_enable'] = 0x7

        if self._board_type == "XTPM":
            self.board[('pll', 0xF)] = 0x1
            self.pll_config(fsample)
            self.pll_config(fsample)
            self.board['fpga1.pps_manager.sync_cnt_enable'] = 0  # disable sync
            self.board['fpga2.pps_manager.sync_cnt_enable'] = 0  # disable sync
        else:
            raise PluginError("TpmPll: Board type not supported")

    ##################### Superclass method implementations #################################

    def initialise(self):
        """ Initialise TpmPll """
        logging.info("TpmPll has been initialised")
        return True

    def status_check(self):
        """ Perform status check
        :return: Status
        """
        logging.info("TpmPll : Checking status")

        if self.board[('pll', 0x508)] not in [0xF2, 0xE7]:
            logging.error('TpmPLL: PLL not initialised')
            return Status.BoardError
        return Status.OK

    def clean_up(self):
        """ Perform cleanup
        :return: Success
        """
        logging.info("TpmPll : Cleaning up")
        return True
