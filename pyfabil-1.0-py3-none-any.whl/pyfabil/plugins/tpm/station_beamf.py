from __future__ import division
from builtins import range
from pyfabil.plugins.firmwareblock import FirmwareBlock
from pyfabil.base.definitions import *

import logging
import time

__author__ = 'gcomoretto'


class StationBeamformer(FirmwareBlock):
    """ Ring (station) beamformer """

    @compatibleboards(BoardMake.TpmBoard, BoardMake.Tpm16Board)
    @friendlyname('station_beamf')
    @maxinstances(2)
    def __init__(self, board, **kwargs):
        """ StationBeamformer initialiser
        :param board: Pointer to board instance
        """
        super(StationBeamformer, self).__init__(board)

        if 'device' not in list(kwargs.keys()):
            raise PluginError("StationBeamformer: Require a node instance")
        self._device = kwargs['device']

        if self._device == Device.FPGA_1:
            self._device = 'fpga1'
        elif self._device == Device.FPGA_2:
            self._device = 'fpga2'
        else:
            raise PluginError("StationBeamformer: Invalid device %s" % self._device)

        # Number of channels, beams, etc
        self.max_nof_chans = 384
        self.nof_chans = 256  # 128 channels/FPGA for now (256 total)
        self.beam_table = 48 * [0]
        self.freq_table = list(range(64, 512 - 64, 8))

        # Lots of magic numbers. To be tuned for best performance
        # Timing
        # TPM to TPM frame time is enough to send all packets, for
        # the maximum number of channels, in 90% of the time required
        # to receive them
        # CSP frame time is a bit less than twice, as sample size is halved

        self.clock_frequency = 237.037e6
        self.tpm_frame_time = 1080e-9 * 2048 / self.max_nof_chans * 0.9
        self.csp_frame_time = 1080e-9 * 2048 / self.max_nof_chans * 0.9 * 1.85

        # Corner turner block length in CSP blocks
        # 1 means that CSP blocks cycle through all channels
        # without further corner turning
        self.int_block_length = 1
        self.int_block_ovl = 0
        self.ddr_timeout = 1500  # DDR timeout in clock cycles
        self.csp_scaling = 4  # CSP scaling in bits
        self.first_tile = False
        self.last_tile = False
        self.started = False

    ############################################################################
    # Defines if a tile is first, last, both or intermediate.
    ############################################################################
    def set_first_last_tile(self, isFirst, isLast):
        """ Defines if a tile is first, last, both or intermediate
            Parameters: isFirst, isLast, boolean
            One, and only one tile must be first, and last, in a chain
            A tile can be both (one tile chain), or none """

        if self.is_running():
            return False

        self.first_tile = isFirst
        self.last_tile = isLast

        control = 0
        if self.first_tile:
            control |= 0x2
        if self.last_tile:
            control |= 0x4
        self.board['%s.beamf_ring.control' % self._device] = control
        return True

    ############################################################################
    # Initialize
    # Resets hardware.
    ############################################################################
    def initialize(self):
        """ Initialise Station Beamformer """

        if self.is_running():
            return False

        # Reset beamformer
        self.board['%s.beamf_ring.control.reset' % self._device] = 1
        self.board['%s.beamf_ring.control.reset' % self._device] = 0

        # set start and stop time in the past
        self.board['%s.beamf_ring.start_frame' % self._device] = 2
        self.board['%s.beamf_ring.last_frame' % self._device] = 1
        self.program_timing()
        self.board['%s.beamf_ring.ch_n' % self._device] = self.nof_chans

        control = 0
        if self.first_tile:
            control |= 0x2
        if self.last_tile:
            control |= 0x4

        self.board['%s.beamf_ring.control' % self._device] = control
        self.board['%s.beamf_ring.csp_scaling' % self._device] = self.csp_scaling

        # reset errors
        self.board['%s.beamf_ring.control.error_rst' % self._device] = 1
        self.board['%s.beamf_ring.control.error_rst' % self._device] = 0

        # set tentatively the epoch using local clock
        # Should be refined by the TM
        timestamp = self.board['%s.beamf_ring.current_frame' % self._device] * 256. * 1.080e-6
        self.epoch = int(round(time.time() - timestamp))
        self.set_epoch(self.epoch)

        logging.info("StationBeamformer has been initialised")
        return True

    ############################################################################
    # Private method to program the channel table
    # from the values stored in the object
    # Valid only for the last tile
    ############################################################################
    def program_channels(self):

        if self.is_running():
            return False

        self.board['%s.beamf_ring.ch_n' % self._device] = self.nof_chans
        if self.last_tile == False:
            return False
        freq_beam_table = [0] * (self.nof_chans // 8)
        for i in range(self.nof_chans // 8):
            freq_beam_table[i] = 0x200 * self.beam_table[i] + self.freq_table[i]

        self.board['%s.beamf_ring.ch_n' % self._device] = self.nof_chans
        self.board['%s.beamf_ring.freq_beam_tab' % self._device] = freq_beam_table
        return True

    ############################################################################
    # Define the channel table, for last tile
    ############################################################################
    def defineChannelTable(self, region_array):
        """ Set frequency regions.
            Regions are defined in a 2-d array, for a maximum of 16 regions.
            Each element in the array defines a region, with
            the form [start_ch, nof_ch, beam_index]
            - start_ch:    region starting channel (currently must be a
                           multiple of 2, LS bit discarded)
            - nof_ch:      size of the region: must be multiple of 8 chans
            - beam_index:  beam used for this region, range [0:8)
            Total number of channels must be <= 384
            The routine computes the arrays beam_index, region_off, region_sel,
            and the total number of channels nof_chans, and programs it in the HW"""

        region_idx = 0
        self.beam_table = 64 * [0]
        self.freq_table = 64 * [0]
        for region in region_array:
            start_ch = region[0]
            reg_length = region[1] & 0X1F8
            if reg_length > 384:
                raise PluginError("StationBeamformer: Invalid region length in %s" % self._device)
            end_ch = start_ch + reg_length
            if start_ch < 0 or end_ch > 512:
                raise PluginError("StationBeamformer: Invalid region position in %s" % self._device)
            reg_length = reg_length // 8
            if region_idx + reg_length > 64:
                raise PluginError("StationBeamformer: too many channels specified in %s" % self._device)
            self.beam_table[region_idx:(region_idx + reg_length)] = [region[2]] * reg_length
            self.freq_table[region_idx:(region_idx + reg_length)] = list(range(start_ch, end_ch, 8))
            region_idx = region_idx + reg_length

        self.nof_chans = region_idx * 8

        return self.program_channels()

    ############################################################################
    # Private method to set the timing registers
    # from constants set during initialization (or modified afterwards)
    ############################################################################
    def program_timing(self):
        if self.is_running():
            return False
        self.board['%s.beamf_ring.frame_rate.first_tile' % self._device] = \
            int(round(self.tpm_frame_time * self.clock_frequency))
        self.board['%s.beamf_ring.frame_rate.last_tile' % self._device] = \
            int(round(self.csp_frame_time * self.clock_frequency))
        self.board['%s.beamf_ring.timeout' % self._device] = \
            self.ddr_timeout
        self.board['%s.beamf_ring.frame_timing.int_block_len' % self._device] = \
            self.int_block_length
        self.board['%s.beamf_ring.frame_timing.int_block_ovl' % self._device] = \
            self.int_block_ovl
        return True

    ############################################################################
    # Define the SPEAD header, for last tile
    ############################################################################
    def define_spead_header(self, stationId, subarrayId, numAntennas, refEpoch=-1, startTime=0):
        """ define_spead_header() used to define SPEAD header for last tile
            requires stationId, subarrayId and numAntennas from LMC
            refEpoch = -1 (default) uses value already defined ib set_epoch()
            startTime (in seconds): offset from frame time, default 0 """
        if self.is_running():
            return False
        self.board['%s.beamf_ring.frame_id.antenna_index' % self._device] = numAntennas
        self.board['%s.beamf_ring.frame_id.station_id' % self._device] = stationId
        self.board['%s.beamf_ring.frame_id.sub_array_id' % self._device] = subarrayId
        if refEpoch != -1:
            self.set_epoch(refEpoch)
        self.board['%s.beamf_ring.start_time' % self._device] = \
            int(startTime * 1e9) & 0xffffffff

        return True

    ############################################################################
    # Set the Unix epoch in seconds since Unix reference time
    ############################################################################
    def set_epoch(self, epoch):
        """ Set the Unix epoch in seconds since Unix reference time"""
        self.epoch = epoch & 0xffffffffff
        self.board['%s.beamf_ring.ref_epoch_lo' % self._device] = epoch & 0xffffffff
        self.board['%s.beamf_ring.ref_epoch_hi' % self._device] = (epoch >> 32) & 0xff
        return True

    ############################################################################
    # Set output rounding for CSP
    ############################################################################
    def set_csp_rounding(self, rounding):
        """
        Sets the number of bits rounded off before sending the result to the CSP.
        For white noise it should be log2(sqrt(nof_antennas)),
        i.e. 4 for 256 antennas
        """
        if rounding < 0:
            rounding = 0
        if rounding > 7:
            rounding = 7
        self.csp_rounding = rounding
        self.board['%s.beamf_ring.csp_scaling' % self._device] = rounding
        return True

    ############################################################################
    # Return current frame
    ############################################################################
    def current_frame(self):
        """ Return current frame, in units of 256 ADC frames (276,48 us)"""
        return self.board['%s.beamf_ring.current_frame' % self._device]

    ############################################################################
    # Start the beamformer
    ############################################################################
    def start(self, time=0, duration=-1):
        """ starts an integration
        The integration is specified in units of 256 ADC frames
        from start_frame (included) to stop_frame (excluded).
        Default for stop_frame is -1 = "forever" """
        if self.is_running():
            return False

        # Reset beamformer to be sure everythig is OK
        self.board['%s.beamf_ring.control.reset' % self._device] = 1
        self.board['%s.beamf_ring.control.reset' % self._device] = 0

        # Program start and stop times
        if time == 0:
            time = self.current_frame() + 48
        time &= 0xfffffff8

        if duration == -1:
            end_time = 0xffffffff
        else:
            duration &= 0xfffffff8
            end_time = time + duration  # +1

        self.board['%s.beamf_ring.start_frame' % self._device] = time
        self.board['%s.beamf_ring.last_frame' % self._device] = end_time
        self.started = True
        return True

    ############################################################################
    # Check if the beamformer is still running.
    # First check internal variable in login, then check if end time has elapsed
    ############################################################################
    def is_running(self):
        if not self.started:
            return False
        if self.board['%s.beamf_ring.last_frame' % self._device] > self.current_frame():
            return True
        self.started = False
        return False

    ############################################################################
    # Stop the beamformer
    ############################################################################
    def abort(self):
        self.board['%s.beamf_ring.last_frame' % self._device] = 1
        self.started = False
        return True

    ############################################################################
    # Report errors
    ############################################################################
    def report_errors(self):
        """
       Return frame errors and general error flag word, fetched by status_check()
       """
        return [self.frame_errors, self.errors]

    ############################################################################
    # Some default methods
    ############################################################################
    def status_check(self):
        """ Perform status check
        Checks if framing errors are present
        :return: Status
        """
        logging.info("StationBeamformer: Checking status")
        self.frame_errors = self.board['%s.beamf_ring.error.frame_error' % self._device]
        self.errors = (self.board['%s.beamf_ring.error' % self._device] >> 16) & 0x3f
        if self.frame_errors == 0:
            return Status.OK
        logging.info("StationBeamformer: Frame errors %d" % this.frame_error)
        return Status.Error

    def initialise(self, **kwargs):
        pass

    def clean_up(self):
        """ Perform cleanup
        :return: Success
        """
        logging.info("StationBeamformer : Cleaning up")
        return True
