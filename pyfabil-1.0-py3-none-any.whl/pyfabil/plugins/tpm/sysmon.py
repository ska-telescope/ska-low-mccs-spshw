from __future__ import division
from builtins import str
__author__ = 'chiello'

from pyfabil.plugins.firmwareblock import FirmwareBlock
from pyfabil.base.definitions import *
from pyfabil.base.utils import *
import logging
import time

class TpmSysmon(FirmwareBlock):
    """ FirmwareBlock tests class """

    @compatibleboards(BoardMake.TpmBoard, BoardMake.Tpm16Board)
    @friendlyname('tpm_sysmon')
    @maxinstances(2)
    def __init__(self, board, **kwargs):
        """ TpmSysmon initialiser
        :param board: Pointer to board instance
        """
        super(TpmSysmon, self).__init__(board)

        self._board_type = kwargs.get('board_type', 'XTPM')

        if 'device' not in list(kwargs.keys()):
            raise PluginError("TpmFpga: Require a node instance")
        self._device = kwargs['device']

        if self._device == Device.FPGA_1:
            self._device = 'fpga1'
        elif self._device == Device.FPGA_2:
            self._device = 'fpga2'
        else:
            raise PluginError("TpmFpga: Invalid device %s" % self._device)

    def initialize(self):
        """ Reset System Monitor """
        self.board['%s.sys_mon.sysmonrr' % self._device] = 0x1
        self.board['%s.sys_mon.sysmonrr' % self._device] = 0x0

    def get_fpga_temperature(self):
        """ Read FPGA temperature"""
        rdval = self.board['%s.sys_mon.temp' % self._device]
        temp = ((rdval * 501.3743) / 65536) - 273.67777
        return temp

    def read_adx(self, ad_idx):
        """ Read specified AD to get VAUX"""
        if int(ad_idx) > 15 or int(ad_idx) < 0:
            logging.error('%s sysmon, invalid AD index %s' % (self._device, str(ad_idx)))
            return -1
        else:
            rdval = self.board['%s.sys_mon.vaux_%s' % (self._device, str(ad_idx))]
            voltage = float(rdval) * 1/65536
            return voltage

    def read_conf_regs(self):
        """ Read consifguration registers"""
        rdval0 = self.board['%s.sys_mon.conf_reg_0' % self._device]
        rdval1 = self.board['%s.sys_mon.conf_reg_1' % self._device]
        rdval2 = self.board['%s.sys_mon.conf_reg_2' % self._device]
        rdval3 = self.board['%s.sys_mon.conf_reg_3' % self._device]
        return rdval0, rdval1, rdval2, rdval3

    def get_vcc_int(self):
        """ Read internal VCC"""
        val = self.board['%s.sys_mon.vccint' % self._device]
        val = float(val)/65536*3
        return val

    def get_vcc_aux(self):
        """ Read internal VAUX"""
        val = self.board['%s.sys_mon.vccaux' % self._device]
        val = float(val)/65536*3
        return val

    def get_vcc_fe(self):
        expected = 0.934
        nominal = 3.5
        if self._device == "fpga1":
            vcc = self.read_adx(6)
        else:
            vcc = self.read_adx(8)
        vcc = vcc / expected * nominal
        return vcc


##################### Superclass method implementations #################################

def initialise(self):
    """ Initialise TpmSysmon """
    logging.info("TpmSysmon has been initialised")
    return True


def status_check(self):
    """ Perform status check
    :return: Status
    """
    logging.info("TpmSysmon : Checking status")
    return Status.OK


def clean_up(self):
    """ Perform cleanup
    :return: Success
    """
    logging.info("TpmSysmon : Cleaning up")
    return True


