__author__ = 'lessju'

from pyfabil.plugins.firmwareblock import FirmwareBlock
from pyfabil.base.definitions import *
from pyfabil.base.utils import *
from time import sleep
import logging


class TpmAdc9695(FirmwareBlock):
    """ TpmAdc tests class """

    @compatibleboards(BoardMake.Tpm16Board)
    @friendlyname('tpm_adc')
    @maxinstances(16)
    def __init__(self, board, **kwargs):
        """ TpmAdc initialiser
        :param board: Pointer to board instance
        """
        super(TpmAdc9695, self).__init__(board)

        if 'adc_id' not in kwargs.keys():
            raise PluginError("TpmAdc: adc_id required")
        self._adc_id = kwargs['adc_id']

    #######################################################################################

    def adc_single_start(self, mono_channel_14_bit=False, adc_test_pattern=0x0):
        """ Perform the ADC configuration and initialization procedure as implemented in ADI demo """

        # JESD: 800 MSPS - 2 VCs - 2 lanes
        # N'=8 n=8
        # L = 2 M = 2 F = 1 S = 1 HD = 0

        self.board[(self._adc_id, 0x0)] = 0x81 # reset
        sleep(0.1)
        self.board[(self._adc_id, 0x571)] = 0x15  # JESD Link mode Control 1 - restart

        self.board[(self._adc_id, 0x3f)] = 0x80  # disable power down
        self.board[(self._adc_id, 0x40)] = 0x00  # FD_A|B pins configured as Fast Detect outputs.

        self.board[(self._adc_id, 0x120)] = 0xA  # sysref
        self.board[(self._adc_id, 0x200)] = 0x0
        self.board[(self._adc_id, 0x201)] = 0x0
        self.board[(self._adc_id, 0x550)] = adc_test_pattern  # ADC test mode
        # self.board[(self._adc_id, 0x573)] = 0x00  # test mode disable

        self.board[(self._adc_id, 0x56E)] = 0x0   # Lane Rate

        self.board[(self._adc_id, 0x572)] = 0x10  # SYNC CMOS level

        self.board[(self._adc_id, 0x58b)] = 0x81  # JESD204B scrambler and lanes.
        self.board[(self._adc_id, 0x58c)] = 0x0   # JESD204B number of octects (F)
        self.board[(self._adc_id, 0x58d)] = 0x1f  # JESD204B number of frame per multiframe (K)
        self.board[(self._adc_id, 0x58e)] = 0x1   # JESD204B number of converters (M)
        self.board[(self._adc_id, 0x58f)] = 0x7   # JESD204B number of control bits (CS) and ADC resolution (N)
        self.board[(self._adc_id, 0x590)] = 0x27  # JESD204B Subclass and number of bits per sample (N')

        # pre-emphais test
        # pre_emphasis = 0xc
        # self.board[(self._adc_id, 0x5c4)] = pre_emphasis
        # self.board[(self._adc_id, 0x5c6)] = pre_emphasis

        # Lane remap
        self.board[(self._adc_id, 0x5b2)] = 0x00
        self.board[(self._adc_id, 0x5b3)] = 0x01
        self.board[(self._adc_id, 0x5b5)] = 0x00
        self.board[(self._adc_id, 0x5b6)] = 0x01
        self.board[(self._adc_id, 0x5b0)] = 0x50  # xTPM unused lane power down

        self.board[(self._adc_id, 0x571)] = 0x14

        self.board[(self._adc_id, 0x1228)] = 0x4F  # Reset JESD204B start-up circuit
        self.board[(self._adc_id, 0x1228)] = 0x0F  # JESD204B start-up circuit in normal operation
        self.board[(self._adc_id, 0x1222)] = 0x00  # JESD204B PLL force normal operation
        self.board[(self._adc_id, 0x1222)] = 0x04  # Reset JESD204B PLL calibration
        self.board[(self._adc_id, 0x1222)] = 0x00  # JESD204B PLL normal operation
        self.board[(self._adc_id, 0x1262)] = 0x08  # Clear loss of lock bit
        self.board[(self._adc_id, 0x1262)] = 0x00  # Loss of lock bit normal operation

        if do_until_eq(lambda: self.board[(self._adc_id, 0x56F)] == 0x80, 1, ms_retry=100, s_timeout=5) is None:
            logging.warning("%s configuration failed" % self._adc_id)
        else:
            logging.debug("%s configuration OK" % self._adc_id)

    # ##################### Superclass method implementations #################################

    def initialise(self):
        """ Initialise TpmPll """
        logging.info("TpmAdc has been initialised")
        return True

    def status_check(self):
        """ Perform status check
        :return: Status
        """

        logging.info("TpmAdc : Checking status")
        return Status.OK

    def clean_up(self):
        """ Perform cleanup
        :return: Success
        """
        logging.info("TpmAdc : Cleaning up")
        return True
