__author__ = 'gabriele.sorrenti'

from pyfabil.base.definitions import *
from pyfabil.base.utils import *
from pyfabil.plugins.firmwareblock import FirmwareBlock


class Tpm_1_6_EEP(FirmwareBlock):
    """ TpmAdc tests class """

    @compatibleboards(BoardMake.Tpm16Board)
    @friendlyname('tpm_eep')
    @maxinstances(1)
    def __init__(self, board, **kwargs):
        """ TpmAdc initialiser
        :param board: Pointer to board instance
        """
        super(Tpm_1_6_EEP, self).__init__(board)

        self.phy_addr = 0xA0
        self.ba = 0x40000000

        self.eep_sec = {
            "ip_address":       {"offset": 0x00, "size":  4, "name": "ip_address",       "type": "ip"},
            "netmask":          {"offset": 0x04, "size":  4, "name": "netmask",          "type": "ip"},
            "gateway":          {"offset": 0x08, "size":  4, "name": "gateway",          "type": "ip"},
            "password":         {"offset": 0x0c, "size":  4, "name": "password",         "type": "bytearray"},
            "pre_adu_0":        {"offset": 0x10, "size": 16, "name": "pre_adu_0",        "type": "bytearray"},
            "pre_adu_1":        {"offset": 0x20, "size": 16, "name": "pre_adu_1",        "type": "bytearray"},
            "SN":               {"offset": 0x40, "size": 16, "name": "SN",               "type": "string"},
            "PN":               {"offset": 0x50, "size": 16, "name": "PN",               "type": "string"},
            "BOARD_MODE":       {"offset": 0x60, "size":  1, "name": "BOARD_MODE", "type": "uint"},  # 0 ada,0xff no-ada
            "HARDWARE_REV":     {"offset": 0x61, "size":  3, "name": "HARDWARE_REV",  "type": "bytearray"},  # v00.00.00
            "CABINET_LOCATION": {"offset": 0x66, "size":  2, "name": "CABINET_LOCATION", "type": "uint"},
            "SUBRACK_LOCATION": {"offset": 0x68, "size":  1, "name": "SUBRACK_LOCATION", "type": "uint"},
            "SLOT_LOCATION":    {"offset": 0x69, "size":  1, "name": "SLOT_LOCATION",    "type": "uint"},
            "MAC":              {"offset": 0xFA, "size":  6, "name": "MAC",           "type": "bytearray"},  # READ-ONLY
        }

    #######################################################################################

    def rd8(self, offset, use_password=False):
        """ Read 8-bit value from EEP ROM """
        self.set_passwd()
        add = self.phy_addr >> 1
        nof_rd_byte = 1
        nof_wr_byte = 1
        cmd = (nof_rd_byte << 12) + (nof_wr_byte << 8) + add
        self.board[self.ba + 0x4] = offset & 0xFF
        self.board[self.ba + 0x0] = cmd
        while self.board[self.ba + 0xC] != 0:
            pass
        self.remove_passwd()
        return self.board[self.ba + 0x8]

    def rd16(self, offset):
        rd = 0
        for n in range(2):
            rd = rd << 8
            rd = rd | self.rd8(offset+n)
        return rd

    def rd32(self, offset):
        """ Read 32-bit value from EEP ROM """
        rd = 0
        for n in range(4):
            rd = rd << 8
            rd = rd | self.rd8(offset + n)
        return rd

    def wr8(self, offset, data):
        """ Write 8-bit value to EEP ROM """
        self.set_passwd()
        add = self.phy_addr >> 1
        nof_rd_byte = 0
        nof_wr_byte = 2
        cmd = (nof_rd_byte << 12) + (nof_wr_byte << 8) + add

        while True:
            self.board[self.ba + 0x4] = ((data & 0xFF) << 8) + (offset & 0xFF)
            self.board[self.ba + 0x0] = cmd
            while True:
                rd = self.board[self.ba + 0xC]
                if rd == 2:
                    time.sleep(0.1)
                    break
                elif rd == 0:
                    time.sleep(0.005)
                    self.remove_passwd()
                    return
                else:
                    time.sleep(0.1)

    def rd16(self, offset):
        rd = 0
        for n in range(2):
            rd = rd << 8
            rd = rd | self.rd8(offset+n)
        return rd

    def rd32(self, offset):
        rd = 0
        for n in range(4):
            rd = rd << 8
            rd = rd | self.rd8(offset+n)
        return rd

    def wr32(self, offset, data):
        for n in range(4):
            self.wr8(offset+n, (data >> 8*(3-n)) & 0xFF)
        return

    def wr_string(self, partition, string):
        return self._wr_string(partition["offset"], string, partition["size"])

    def _wr_string(self, offset, string, max_len=16):
        addr = offset
        for i in range(len(string)):
            self.wr8(addr, ord(string[i]))
            addr += 1
            if addr >= offset + max_len:
                break
        if addr < offset + max_len:
            self.wr8(addr, ord("\n"))

    def rd_string(self, partition):
        return self._rd_string(partition["offset"], partition["size"])

    def _rd_string(self, offset, max_len=16):
        addr = offset
        string = ""
        for i in range(max_len):
            byte = self.rd8(addr)
            if byte == ord("\n") or byte == 0xff:
                break
            string += chr(byte)
            addr += 1
        return string

    def set_passwd(self):
        rd = self.board[0x40000020]
        self.board[0x4000003C] = rd
        rd = self.board[0x40000024]
        self.board[0x40000038] = rd

        rd = self.board[0x4000003C]
        if rd & 0x10000 == 0:
            raise LibraryError("I2C/EEP password not accepted!")

    def remove_passwd(self):
        self.board[0x4000003C] = 0
        self.board[0x40000038] = 0

    def get_field(self, key):
        if self.eep_sec[key]["type"] == "ip":
            return long2ip(self.rd32(self.eep_sec[key]["offset"]))
        elif self.eep_sec[key]["type"] == "bytearray":
            arr = bytearray()
            for offset in range(self.eep_sec[key]["size"]):
                arr.append(self.rd8(self.eep_sec[key]["offset"]+offset))
            return arr
        elif self.eep_sec[key]["type"] == "string":
            return self.rd_string(self.eep_sec[key])
        elif self.eep_sec[key]["type"] == "uint":
            val=0
            for offset in range(self.eep_sec[key]["size"]):
                val = val * 256 + self.rd8(self.eep_sec[key]["offset"]+offset)
            return val

    def set_field(self, key, value):
        if self.eep_sec[key]["type"] == "ip":
            self.wr32(self.eep_sec[key]["offset"], ip2long(value))
        elif self.eep_sec[key]["type"] == "bytearray":
            for offset in range(self.eep_sec[key]["size"]):
                self.wr8(self.eep_sec[key]["offset"] + offset, value)
        elif self.eep_sec[key]["type"] == "string":
            self.wr_string(self.eep_sec[key], value)
        elif self.eep_sec[key]["type"] == "uint":
            val = value
            for offset in range(self.eep_sec[key]["size"]):
                self.wr8(self.eep_sec[key]["offset"]+offset, val & 0xff)
                val = val >> 8
