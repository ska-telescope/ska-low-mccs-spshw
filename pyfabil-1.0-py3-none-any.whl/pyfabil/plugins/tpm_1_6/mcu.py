__author__ = 'Bubs'

import logging

from pyfabil.base.definitions import *
from pyfabil.base.utils import *
from pyfabil.plugins.firmwareblock import FirmwareBlock

FRAM_BA = 0x90000000


class McuRegisters(object):
    FRAM_MCU_VERSION = 0x00000000
    FRAM_MCU_COMPILE_DATE = 0x00000004
    FRAM_MCU_GIT_HASH = 0x00000008
    FRAM_MCU_GPR_0 = 0x0000000C
    FRAM_MCU_GPR_1 = 0x00000010
    FRAM_MCU_GPR_2 = 0x00000014
    FRAM_MCU_GPR_3 = 0x00000018
    FRAM_MCU_POOLING_INTERVAL = 0x0000001C
    FRAM_MCU_INTERNAL_COMMAND = 0x00000020
    FRAM_MCU_COUNTER = 0x00000024
    FRAM_MCU_COMPLETE_ADC_COUNTER = 0x00000028
    FRAM_MCU_BOOTLOADER_VERSION = 0x0000002C
    FRAM_MCU_BOOTLOADER_COMMANDS = 0x00000030

    FRAM_BOARD_STATUS = 0x000000E0
    FRAM_BOARD_ALARM = 0x000000E4
    FRAM_BOARD_WARNING = 0x000000E8

    FRAM_POWERGOOD = 0x000000FC
    FRAM_ADC_SW_AVDD1 = 0x00000100
    FRAM_ADC_SW_AVDD2 = 0x00000104
    FRAM_ADC_AVDD3 = 0x00000108
    FRAM_ADC_MAN_1V2 = 0x0000010C
    FRAM_ADC_DDR0_VREF = 0x00000110
    FRAM_ADC_DDR1_VREF = 0x00000114
    FRAM_ADC_VM_DRVDD = 0x00000118
    FRAM_ADC_VIN_SCALED = 0x0000011C
    FRAM_ADC_VM_MAN3V3 = 0x00000120
    FRAM_ADC_VM_MAN1V8 = 0x00000124
    FRAM_ADC_MON_5V0 = 0x00000128
    FRAM_ADC_MGT_AV = 0x0000012C
    FRAM_ADC_MGT_AVTT = 0x00000130
    FRAM_ADC_INTERNAL_MCU_TEMP = 0x00000134
    FRAM_BOARD_TEMP = 0x00000138
    FRAM_FPGA0_TEMP = 0x0000013C
    FRAM_FPGA1_TEMP = 0x00000140
    FRAM_FPGA0_FE_CURRENT = 0x00000144
    FRAM_FPGA1_FE_CURRENT = 0x00000148

    FRAM_WARN_ALARM_UPDATE = 0x00000190

    FRAM_WARN_THR_SW_AVDD1 = 0x00000194
    FRAM_WARN_THR_SW_AVDD2 = 0x00000198
    FRAM_WARN_THR_AVDD3 = 0x0000019C
    FRAM_WARN_THR_MAN_1V2 = 0x000001A0
    FRAM_WARN_THR_DDR0_VREF = 0x000001A4
    FRAM_WARN_THR_DDR1_VREF = 0x000001A8
    FRAM_WARN_THR_VM_DRVDD = 0x000001AC
    FRAM_WARN_THR_VIN_SCALED = 0x000001B0
    FRAM_WARN_THR_VM_MAN3V3 = 0x000001B4
    FRAM_WARN_THR_VM_MAN1V8 = 0x000001B8
    FRAM_WARN_THR_MON_5V0 = 0x000001BC
    FRAM_WARN_THR_MGT_AV = 0x000001C0
    FRAM_WARN_THR_MGT_AVTT = 0x000001C4
    FRAM_WARN_THR_INTERNAL_MCU_TEMP = 0x000001C8
    FRAM_WARN_THR_BOARD_TEMP = 0x000001CC
    FRAM_WARN_THR_FPGA0_TEMP = 0x000001D0
    FRAM_WARN_THR_FPGA1_TEMP = 0x000001D4
    FRAM_WARN_THR_FPGA0_FE_CURRENT = 0x000001D8
    FRAM_WARN_THR_FPGA1_FE_CURRENT = 0x000001E0

    FRAM_ALARM_THR_SW_AVDD1 = 0x00000220
    FRAM_ALARM_THR_SW_AVDD2 = 0x00000224
    FRAM_ALARM_THR_AVDD3 = 0x00000228
    FRAM_ALARM_THR_MAN_1V2 = 0x0000022C
    FRAM_ALARM_THR_DDR0_VREF = 0x00000230
    FRAM_ALARM_THR_DDR1_VREF = 0x00000234
    FRAM_ALARM_THR_VM_DRVDD = 0x00000238
    FRAM_ALARM_THR_VIN_SCALED = 0x0000023C
    FRAM_ALARM_THR_VM_MAN3V3 = 0x00000240
    FRAM_ALARM_THR_VM_MAN1V8 = 0x00000244
    FRAM_ALARM_THR_MON_5V0 = 0x00000248
    FRAM_ALARM_THR_MGT_AV = 0x0000024C
    FRAM_ALARM_THR_MGT_AVTT = 0x00000250
    FRAM_ALARM_THR_INTERNAL_MCU_TEMP = 0x00000254
    FRAM_ALARM_THR_BOARD_TEMP = 0x00000258
    FRAM_ALARM_THR_FPGA0_TEMP = 0x0000025C
    FRAM_ALARM_THR_FPGA1_TEMP = 0x00000260
    FRAM_ALARM_THR_FPGA0_FE_CURRENT = 0x00000264
    FRAM_ALARM_THR_FPGA1_FE_CURRENT = 0x00000268

    MCU_ADC_OFFSET = FRAM_ADC_SW_AVDD1
    ALARM_THR_OFFSET = FRAM_ALARM_THR_SW_AVDD1
    TEMPS_OFFSET = FRAM_BOARD_TEMP


class Tpm_1_6_Mcu(FirmwareBlock):
    """ FirmwareBlock tests class """

    @compatibleboards(BoardMake.Tpm16Board)
    @friendlyname('tpm_monitor')
    @maxinstances(1)
    def __init__(self, board, **kwargs):
        """ TpmMcu initialiser
        :param board: Pointer to board instance
        """
        super(Tpm_1_6_Mcu, self).__init__(board)

        self._board_type = kwargs.get('board_type', 'XTPM')

    #######################################################################################
    def get_version(self):
        version = hex(self.board.read_address(FRAM_BA + McuRegisters.FRAM_MCU_VERSION)) + "_"
        version += hex(self.board.read_address(FRAM_BA + McuRegisters.FRAM_MCU_COMPILE_DATE)) + "_"
        version += hex(self.board.read_address(FRAM_BA + McuRegisters.FRAM_MCU_INTERNAL_COMMAND))
        return version

    def _get_adc_value(self, adc_measure):
        add = FRAM_BA + McuRegisters.MCU_ADC_OFFSET
        found = False
        value = 0
        for i in range(0, len(McuRegisters.MCU_ADC)):
            if adc_measure == McuRegisters.MCU_ADC[i]:
                value = self.board.read_address(add+(i*0x4))
                found = True
                break
        if found:
            op_status = 0
        else:
            op_status = -1
        return value, op_status

    def get_voltage_5v0(self):
        return round(self.board.read_address(FRAM_BA + McuRegisters.FRAM_ADC_MON_5V0) * 0.001, 2)

    def get_voltage_fpga0(self):
        return None

    def get_voltage_fpga1(self):
        return None

    def get_voltage_av(self):
        return round(self.board.read_address(FRAM_BA + McuRegisters.FRAM_ADC_MGT_AV) * 0.001, 2)

    def get_voltage_avtt(self):
        return round(self.board.read_address(FRAM_BA + McuRegisters.FRAM_ADC_MGT_AVTT) * 0.001, 2)

    def get_voltage_vcc_aux(self):
        return None

    def get_voltage_avdd1(self):
        return round(self.board.read_address(FRAM_BA + McuRegisters.FRAM_ADC_SW_AVDD1) * 0.001, 2)

    def get_voltage_avdd2(self):
        return round(self.board.read_address(FRAM_BA + McuRegisters.FRAM_ADC_SW_AVDD2) * 0.001, 2)

    def get_voltage_avdd3(self):
        return round(self.board.read_address(FRAM_BA + McuRegisters.FRAM_ADC_AVDD3) * 0.001, 2)

    def get_temperature(self):
        step = 0.0625
        temp = (self.board.read_address(FRAM_BA + McuRegisters.FRAM_BOARD_TEMP)) & 0x1fff
        if temp & 0x1000 == 0x1000:
            temp = (temp & 0xfff) - 4096
        else:
            temp = temp & 0xfff
        temp_f = temp * step
        temp_f = round(temp_f, 2)
        return temp_f

    def get_mcu_temperature(self):
        temp = (self.board.read_address(FRAM_BA + McuRegisters.FRAM_ADC_INTERNAL_MCU_TEMP))
        temp_f = float(temp/10000)
        temp_f = round(temp_f, 2)
        return temp_f

    def set_fpga_warn_temp_threshold(self, max_temp, min_temp):
        max_value = (max_temp + 273.67777) * 65536 / 501.3743
        min_value = (min_temp + 273.67777) * 65536 / 501.3743
        regval = ((max_value & 0xffff) << 16) | (min_value & 0xffff)
        self.board.write_address((FRAM_BA + McuRegisters.FRAM_WARN_THR_FPGA0_TEMP), regval)
        self.board.write_address((FRAM_BA + McuRegisters.FRAM_WARN_THR_FPGA1_TEMP), regval)
        self.board.write_address((FRAM_BA + McuRegisters.FRAM_WARN_ALARM_UPDATE), 0x1)

    def set_fpga_alm_temp_threshold(self, max_temp, min_temp):
        max_value = (max_temp + 273.67777) * 65536 / 501.3743
        min_value = (min_temp + 273.67777) * 65536 / 501.3743
        regval = ((max_value & 0xffff) << 16) | (min_value & 0xffff)
        self.board.write_address((FRAM_BA + McuRegisters.FRAM_ALARM_THR_FPGA0_TEMP), regval)
        self.board.write_address((FRAM_BA + McuRegisters.FRAM_ALARM_THR_FPGA1_TEMP), regval)
        self.board.write_address((FRAM_BA + McuRegisters.FRAM_WARN_ALARM_UPDATE), 0x1)



    # #################### Superclass method implementations #################################

    def initialise(self):
        """ Initialise TpmMcu """
        logging.info("TpmMcu has been initialised")
        return True

    def status_check(self):
        """ Perform status check
        :return: Status
        """
        logging.info("TpmMcu : Checking status")
        return Status.OK

    def clean_up(self):
        """ Perform cleanup
        :return: Success
        """
        logging.info("TpmMcu : Cleaning up")
        return True
