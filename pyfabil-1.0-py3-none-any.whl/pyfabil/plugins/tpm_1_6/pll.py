from __future__ import division

__author__ = 'lessju'

import logging
import time

from pyfabil.base.definitions import *
from pyfabil.plugins.tpm.pll import TpmPll


class Tpm_1_6_Pll(TpmPll):
    """ FirmwareBlock tests class """

    @compatibleboards(BoardMake.Tpm16Board)
    @friendlyname('tpm_pll')
    @maxinstances(1)
    def __init__(self, board, **kwargs):
        """ TpmPll initialiser
        :param board: Pointer to board instance
        """
        super(Tpm_1_6_Pll, self).__init__(board)

    def pll_reset(self):
        """ Perform the PLL reset
        """
        if self.board["board.regfile.enable.adc"] == 0:
            logging.info("ADCs power disabled. Enabling")
            self.board["board.regfile.enable.adc"] = 1
            time.sleep(0.1)
        else:
            logging.info("ADCs power already enabled.")
        if self.board["board.regfile.enable.sysr"] == 0:
            logging.info("SYS_REF power disabled. Enabling")
            self.board["board.regfile.enable.sysr"] = 1
            time.sleep(0.1)
        else:
            logging.info("SYS_REF power already enabled.")
        self.board['board.regfile.pll.resetn'] = 1
        self.board['board.regfile.pll.resetn'] = 0
        time.sleep(0.2)
        self.board['board.regfile.pll.resetn'] = 1
        time.sleep(0.2)

    def pll_start(self, fsample):
        """ Perform the PLL initialization procedure as implemented in ADI demo
        :param fsample: PLL output frequency in MHz. Supported frequency are 700, 800, 1000 MHz
        """

        if fsample not in [1000e6, 800e6, 700e6]:
            logging.warn("TpmPLL: Frequency " + str(fsample / 1e6) + " MHz is not currently supported.")
            fsample = 800e6

        self.pll_reset()

        self.board['fpga1.pps_manager.pps_in_invert'] = 0x0
        self.board['fpga1.pps_manager.sync_tc'] = 0x07090404
        self.board['fpga1.pps_manager.sync_prescale'] = 0x0
        self.board['fpga1.pps_manager.sync_cnt_enable'] = 0x7

        self.board['fpga2.pps_manager.pps_in_invert'] = 0x0
        self.board['fpga2.pps_manager.sync_tc'] = 0x07090404
        self.board['fpga2.pps_manager.sync_prescale'] = 0x0
        self.board['fpga2.pps_manager.sync_cnt_enable'] = 0x7

        if self._board_type == "XTPM":
            self.board[('pll', 0xF)] = 0x1
            self.pll_config(fsample)
            self.pll_config(fsample)
            self.board['fpga1.pps_manager.sync_cnt_enable'] = 0  # disable sync
            self.board['fpga2.pps_manager.sync_cnt_enable'] = 0  # disable sync
        else:
            raise PluginError("TpmPll: Board type not supported")
