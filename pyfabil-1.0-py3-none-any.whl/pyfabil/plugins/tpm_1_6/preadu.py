from builtins import range

__author__ = 'lessju'

from pyfabil.plugins.firmwareblock import FirmwareBlock
from pyfabil.base.definitions import *
from pyfabil.base.utils import *
from pyfabil.plugins.tpm.preadu import PreAdu
import logging
import time


class Tpm_1_6_PreAdu(PreAdu):
    """ AdcPowerMeter plugin  """

    @compatibleboards(BoardMake.TpmBoard, BoardMake.Tpm16Board)
    @friendlyname('tpm_preadu')
    @maxinstances(2)
    def __init__(self, board, **kwargs):
        """ AdcPowerMeter initialiser
        :param board: Pointer to board instance
        """
        super(Tpm_1_6_PreAdu, self).__init__(board, **kwargs)
        """
        if 'preadu_id' not in list(kwargs.keys()):
            raise PluginError("PreAdu: preadu_id required")
        self._preadu_id = kwargs['preadu_id']

        # Passband filter values
        self._HIGH_PASSBAND = 0x3
        self._LOW_PASSBAND = 0x5

        # Define a filter per channel in order to be able to enable and disable
        # RF output from the channel
        self._nof_channels = 16
        self.channel_filters = [0x0] * self._nof_channels
        self._passband = 0x0

        # Read current configuration
        self.read_configuration()
        """

    #######################################################################################
    def switch_on(self):
        """ Switch preadu on """

        # Switch on preadu
        self.board["regfile.enable.fe"] = 1
        time.sleep(0.2)

        # Check that preadu has been switched on properly
        value = self.board["regfile.enable.fe"] = 1
        if value & (self._preadu_id + 1) != (self._preadu_id + 1):
            logging.warning("Error! preADU power is not high".format(value))
            return
        logging.debug("preADU power on done!")

        # Read and load preadu configuration and
        self.eep_read()
        self.write_configuration()

    def switch_off(self):
        """ Switch preadu off """

        # Switch off preadu
        if (self.board[0x30000040] & 0x3) & (self._preadu_id + 1) == (self._preadu_id + 1):
            self.board[0x3000003c] = (self.board[0x30000040] & 0x3) ^ (self._preadu_id + 1)
        time.sleep(0.2)

        # Check that preadu has been switched off properly
        value = self.board[0x30000040] & 0x3
        if value & (self._preadu_id + 1) == 0x0:
            logging.debug("preADU power off done!")
        else:
            logging.warning("Error! preADU power is not low: {}".format(value))

    def write_configuration(self):
        """ Write configuration to preadu"""

        # Each channel occupies 8-bit within a 32-bit word
        self.board[0x70000000] = self.bit_reverse(self.channel_filters[0]) | \
            self.bit_reverse(self.channel_filters[1]) << 8 |\
            self.bit_reverse(self.channel_filters[2]) << 16 |\
            self.bit_reverse(self.channel_filters[3]) << 24
        self.board[0x70000004] = self.bit_reverse(self.channel_filters[4]) | \
            self.bit_reverse(self.channel_filters[5]) << 8 | \
            self.bit_reverse(self.channel_filters[6]) << 16 | \
            self.bit_reverse(self.channel_filters[7]) << 24
        self.board[0x70000008] = self.bit_reverse(self.channel_filters[8]) | \
            self.bit_reverse(self.channel_filters[9]) << 8 | \
            self.bit_reverse(self.channel_filters[10]) << 16 | \
            self.bit_reverse(self.channel_filters[11]) << 24
        self.board[0x7000000C] = self.bit_reverse(self.channel_filters[12]) | \
            self.bit_reverse(self.channel_filters[13]) << 8 | \
            self.bit_reverse(self.channel_filters[14]) << 16 | \
            self.bit_reverse(self.channel_filters[15]) << 24

        self.board[0x70000010] = (self._preadu_id << 2) | 0x3
        while self.board[0x70000010] & 0x1 != 0x0:
            time.sleep(0.01)

    def read_configuration(self):
        """ Read configuration from preadu """

        self.board[0x70000010] = (self._preadu_id << 2) | 0x1
        while self.board[0x70000010] & 0x1 != 0x0:
            time.sleep(0.01)

        # Each channel occupies 8-bit within a 32-bit word
        config0 = self.board[0x70000000]
        config1 = self.board[0x70000004]
        config2 = self.board[0x70000008]
        config3 = self.board[0x7000000C]

        # Extract channel values
        self.channel_filters[0] = self.bit_reverse(config0 & 0xFF)
        self.channel_filters[1] = self.bit_reverse((config0 >> 8) & 0xFF)
        self.channel_filters[2] = self.bit_reverse((config0 >> 16) & 0xFF)
        self.channel_filters[3] = self.bit_reverse((config0 >> 24) & 0xFF)
        self.channel_filters[4] = self.bit_reverse(config1 & 0xFF)
        self.channel_filters[5] = self.bit_reverse((config1 >> 8) & 0xFF)
        self.channel_filters[6] = self.bit_reverse((config1 >> 16) & 0xFF)
        self.channel_filters[7] = self.bit_reverse((config1 >> 24) & 0xFF)
        self.channel_filters[8] = self.bit_reverse(config2 & 0xFF)
        self.channel_filters[9] = self.bit_reverse((config2 >> 8) & 0xFF)
        self.channel_filters[10] = self.bit_reverse((config2 >> 16) & 0xFF)
        self.channel_filters[11] = self.bit_reverse((config2 >> 24) & 0xFF)
        self.channel_filters[12] = self.bit_reverse(config3 & 0xFF)
        self.channel_filters[13] = self.bit_reverse((config3 >> 8) & 0xFF)
        self.channel_filters[14] = self.bit_reverse((config3 >> 16) & 0xFF)
        self.channel_filters[15] = self.bit_reverse((config3 >> 24) & 0xFF)

        self.board[0x70000010] = (self._preadu_id << 2) | 0x1
        while self.board[0x70000010] & 0x1 != 0x0:
            time.sleep(0.01)

    def eep_write(self, config):
        """ Write current configuration to non-volatile memory """
        self.board.tpm_eep.wr32(0x10 + (16 * self._preadu_id),
                                self.bit_reverse(self.channel_filters[0] +
                                                 (self.channel_filters[1] << 8) +
                                                 (self.channel_filters[2] << 16) +
                                                 (self.channel_filters[3] << 24)))

        self.board.tpm_eep.wr32(0x10 + (16 * self._preadu_id) + 4,
                                self.bit_reverse(self.channel_filters[4] +
                                                 (self.channel_filters[5] << 8) +
                                                 (self.channel_filters[6] << 16) +
                                                 (self.channel_filters[7] << 24)))

        self.board.tpm_eep.wr32(0x10 + (16 * self._preadu_id) + 8,
                                self.bit_reverse(self.channel_filters[8] +
                                                 (self.channel_filters[9] << 8) +
                                                 (self.channel_filters[10] << 16) +
                                                 (self.channel_filters[11] << 24)))

        self.board.tpm_eep.wr32(0x10 + (16 * self._preadu_id) + 12,
                                self.bit_reverse(self.channel_filters[12] +
                                                 (self.channel_filters[13] << 8) +
                                                 (self.channel_filters[14] << 16) +
                                                 (self.channel_filters[15] << 24)))

    def eep_read(self):
        """ Read configuration from non-volatile memory"""
        start_index = 0x10 + (16 * self._preadu_id)
        config0 = self.bit_reverse(self.board.board.tpm_eep.rd32(start_index))
        config1 = self.bit_reverse(self.board.board.tpm_eep.rd32(start_index + 4))
        config2 = self.bit_reverse(self.board.board.tpm_eep.rd32(start_index + 8))
        config3 = self.bit_reverse(self.board.board.tpm_eep.rd32(start_index + 12))

        # Extract channel values
        self.channel_filters[0] = config0 & 0xFF
        self.channel_filters[1] = (config0 >> 8) & 0xFF
        self.channel_filters[2] = (config0 >> 16) & 0xFF
        self.channel_filters[3] = (config0 >> 24) & 0xFF
        self.channel_filters[4] = config1 & 0xFF
        self.channel_filters[5] = (config1 >> 8) & 0xFF
        self.channel_filters[6] = (config1 >> 16) & 0xFF
        self.channel_filters[7] = (config1 >> 24) & 0xFF
        self.channel_filters[8] = config2 & 0xFF
        self.channel_filters[9] = (config2 >> 8) & 0xFF
        self.channel_filters[10] = (config2 >> 16) & 0xFF
        self.channel_filters[11] = (config2 >> 24) & 0xFF
        self.channel_filters[12] = config3 & 0xFF
        self.channel_filters[13] = (config3 >> 8) & 0xFF
        self.channel_filters[14] = (config3 >> 16) & 0xFF
        self.channel_filters[15] = (config3 >> 24) & 0xFF

    @staticmethod
    def bit_reverse(value):
        """ Reverse bits in value
        :param value: Value to bit reverse """
        return int("%d" % (int('{:08b}'.format(value)[::-1], 2)))

    ##################### Superclass method implementations #################################

    def initialise(self):
        """ Initialise AdcPowerMeter """
        logging.info("PreAdu has been initialised")
        return True

    def status_check(self):
        """ Perform status check
        :return: Status
        """
        logging.info("PreAdu: Checking status")
        return Status.OK

    def clean_up(self):
        """ Perform cleanup
        :return: Success
        """
        logging.info("PreAdu: Cleaning up")
        return True
