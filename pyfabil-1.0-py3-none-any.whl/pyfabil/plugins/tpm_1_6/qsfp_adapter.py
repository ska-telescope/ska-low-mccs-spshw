from __future__ import division
from builtins import str
__author__ = 'bubs'

from pyfabil.plugins.firmwareblock import FirmwareBlock
import logging
import time

from pyfabil.base.definitions import *
from pyfabil.plugins.tpm.sysmon import TpmSysmon


IOEXP_map = {
    "LED0n"   :{'ch':1,'output':True},
    "LED1n"   :{'ch':2,'output':True},
    "LED2n"   :{'ch':3,'output':True},
    "LED3n"   :{'ch':0,'output':True},
    "ModPrsL" :{'ch':4,'output':False},
    "IntL"    :{'ch':5,'output':False},
    "ResetL"  :{'ch':6,'output':True},
    "LPMode"  :{'ch':7,'output':True},
    }

i2c_status_busy = 0x1
i2c_status_ack_error = 0x2

itpm_cpld_i2c_mux = [1, 2]

PHY_ioexp = 0x40 #PCF8574TS
PHY_QSFP = 0xa0


class Tpm_1_6_QSFPAdapter(FirmwareBlock):
    """ Tpm_1_6_QSFPAdapter plugin """

    @compatibleboards(BoardMake.Tpm16Board)
    @friendlyname('tpm_qsfp_adapter')
    @maxinstances(2)
    def __init__(self, board, **kwargs):
        """ Tpm_1_6_QSFPAdapter initialiser
        :param board: Pointer to board instance
        :param core_id: Index of plugin instance to select QSFP_ADAPTER 0 or 1
        """
        super(Tpm_1_6_QSFPAdapter, self).__init__(board)

        if 'core_id' not in list(kwargs.keys()):
            logging.error("tpm_qsfp_adapter: core_id required")
            raise PluginError("tpm_qsfp_adapter: core_id required")
        if (kwargs['core_id']) not in range(len(itpm_cpld_i2c_mux)):
            logging.error("tpm_qsfp_adapter: core_id given %s, should be in range "%(kwargs['core_id'],range(len(itpm_cpld_i2c_mux))))
            raise PluginError("tpm_qsfp_adapter: core_id given %s, should be in range "%(kwargs['core_id'],range(len(itpm_cpld_i2c_mux))))
        self.core_id = (kwargs['core_id'])
        self.i2c_mux = itpm_cpld_i2c_mux[self.core_id]


    def __i2c_rd8(self, phy, nof_rd_byte = 1):
        add = phy >> 1
        #nof_rd_byte = 1
        nof_wr_byte = 0
        offset=0
        cmd = (self.i2c_mux << 16) + (nof_rd_byte << 12) + (nof_wr_byte << 8) + add
        self.board['board.i2c.transmit']  = (offset & 0xFF)
        self.board['board.i2c.command']  = cmd
        status = i2c_status_busy
        retry = 10
        while(status == i2c_status_busy):
            status = self.board['board.i2c.status']
            time.sleep(0.1)
            retry -= 1
            pass
        if retry == 0:
            logging.error("tpm_qsfp_adapter.__i2c_rd8: i2c timeout error (PHY %s)"%hex(phy))
            raise PluginError("tpm_qsfp_adapter.__i2c_rd8: i2c timeout error (PHY %s)"%hex(phy))
        if status == i2c_status_ack_error:
            logging.error("tpm_qsfp_adapter.__i2c_rd8: i2c ack error (PHY %s)"%hex(phy))
            raise PluginError("tpm_qsfp_adapter.__i2c_rd8: i2c ack error (PHY %s)"%hex(phy))
        return self.board['board.i2c.receive']

    def __i2c_wr8(self, phy, value):
        add = phy >> 1
        nof_rd_byte = 0
        nof_wr_byte = 1

        cmd = (self.i2c_mux << 16) + (nof_rd_byte << 12) + (nof_wr_byte << 8) + add
        self.board['board.i2c.transmit'] = (value & 0xFF)
        self.board['board.i2c.command'] = cmd
        status = i2c_status_busy
        retry = 10
        while(status == i2c_status_busy and retry > 0):
            status = self.board['board.i2c.status']
            time.sleep(0.1)
            retry -= 1
            pass
        if retry == 0:
            logging.error("tpm_qsfp_adapter.__i2c_wr8: i2c timeout error (PHY %s)"%hex(phy))
            raise PluginError("tpm_qsfp_adapter.__i2c_wr8: i2c timeout error (PHY %s)"%hex(phy))
        if status == i2c_status_ack_error:
            logging.error("tpm_qsfp_adapter.__i2c_wr8: i2c ack error (PHY %s)"%hex(phy))
            raise PluginError("tpm_qsfp_adapter.__i2c_wr8: i2c ack error (PHY %s)"%hex(phy))
        return True

    def configure_port_mode(self):
        actual_value=self.__i2c_rd8(PHY_ioexp)
        #input ports must be set to 1 even if read at 0
        for key in IOEXP_map:
            if not IOEXP_map[key]['output']:
                i=IOEXP_map[key]['ch']
                actual_value = actual_value |  2**i
        self.__i2c_wr8(PHY_ioexp,actual_value)

    def status(self, line=None):
        # if line is None:
        #     logging.info("= IOEXP_map " + str(self.core_id) +" =")
        self.configure_port_mode()
        value=self.__i2c_rd8(PHY_ioexp)
        # logging.info(bin(value))
        ret_value={}
        for key in IOEXP_map:
            i=IOEXP_map[key]['ch']
        #for i in [1,2,3,0,4,5,6,7]:
            if value & 2**i > 0:
                ret_value[key]=1
                # if line is None:
                #     logging.info(key + "\t1")
                # el
                if line == key:
                    return True
            else:
                ret_value[key]=0
                # if line is None:
                #     logging.info(key + "\t0")
                # el
                if line == key:
                    return False
        return ret_value

    def set(self, line, value):
        if IOEXP_map[line]['output']:
            actual_value=self.__i2c_rd8(PHY_ioexp)
            i=IOEXP_map[line]['ch']
            if value > 0:
                actual_value = actual_value | 2**i
            else:
                actual_value = actual_value & ~(2**i)
            #logging.info("IOEXP_map " + str(self.core_id) +" "+line+" "+hex(value))

            #input ports must be set to 1 even if read at 0
            for key in IOEXP_map:
                if not IOEXP_map[key]['output']:
                    i=IOEXP_map[key]['ch']
                    actual_value = actual_value |  2**i

            self.__i2c_wr8(PHY_ioexp,actual_value)
        else:
            logging.error("tpm_qsfp_adapter.set: line %s is NOT output"%line)
            raise PluginError("tpm_qsfp_adapter.set: line %s is NOT output"%line)

    def get(self, line):
        self.configure_port_mode()
        actual_value=self.__i2c_rd8(PHY_ioexp)
        i=IOEXP_map[line]['ch']
        value = ( actual_value & 2**i ) >> i
        #logging.info("IOEXP_map " + str(self.core_id) +" "+line+" "+hex(value))
        return value

    def qsfp_read(self, offset = 0,len = 16):
        if (not self.status("ModPrsL")):
            arr = bytearray()
            string=""
            self.__i2c_wr8(PHY_QSFP,offset)
            for i in range(len):
                arr.append(self.__i2c_rd8(PHY_QSFP))
                string+='{0:02x}'.format(arr[i])
            #logging.info("QSFP: " + string)
            return arr
        else:
            logging.info("QSFP %d: NA cannot dump read from QSFP")
            return None

    def get_line_mapping(self):
        return IOEXP_map

    def irq_status(self):
        irq = self.board['board.regfile.eth10ge.psnt'] & 2**self.core_id
        if irq > 0:
            return False
        else:
            return True

    def irq_clear(self):
        self.__i2c_rd8(PHY_ioexp)
